# Окружение для сборки под aarch64-linux-android (source android/env.sh)
export PATH=$HOME/.cargo/bin:$PATH
export ANDROID_HOME=$HOME/.zcode/android-build/sdk
export ANDROID_NDK_HOME=$ANDROID_HOME/ndk/28.1.13356709
export ANDROID_NDK_ROOT=$ANDROID_NDK_HOME
export JAVA_HOME=$HOME/.zcode/android-build/jdk-17.0.20.1+1
NDK_BIN=$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/bin
export ANDROID_API=29
export CC_aarch64_linux_android=$NDK_BIN/aarch64-linux-android$ANDROID_API-clang
export CXX_aarch64_linux_android=$NDK_BIN/aarch64-linux-android$ANDROID_API-clang++
export AR_aarch64_linux_android=$NDK_BIN/llvm-ar
export RANLIB_aarch64_linux_android=$NDK_BIN/llvm-ranlib
export CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER=$CC_aarch64_linux_android
export CARGO_TARGET_AARCH64_LINUX_ANDROID_AR=$AR_aarch64_linux_android
export BUILD_TOOLS=$ANDROID_HOME/build-tools/36.1.0
