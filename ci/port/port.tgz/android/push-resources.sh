#!/usr/bin/env bash
# Заливает подготовленные ресурсы в files/ приложения через run-as (сборка debuggable).
# android/push-resources.sh <serial>
set -euo pipefail
cd "$(dirname "$0")/.."
S=${1:?serial}
ADB=~/platform-tools/adb
PKG=cat.narezany.horizon
tar -C .local/horizon-client -cf - 26.3 | "$ADB" -s "$S" exec-in run-as $PKG sh -c \
    'mkdir -p files/.local/horizon-client && cd files/.local/horizon-client && rm -rf 26.3 && tar -xf -'
"$ADB" -s "$S" shell run-as $PKG du -sh files/.local/horizon-client/26.3
