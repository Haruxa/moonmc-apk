package cat.narezany.horizon;

import android.app.NativeActivity;
import android.content.Context;
import android.content.Intent;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import android.os.Bundle;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.BaseInputConnection;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.ExtractedText;
import android.view.inputmethod.ExtractedTextRequest;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;

/**
 * The game's NativeActivity with the device's own keyboard: a NativeActivity's input queue
 * loses text that has no key code (Cyrillic, emoji), so an invisible view takes the keyboard's
 * text and hands it to the game (libhorizon's nativeText and nativeKey), in order.
 */
public class HorizonActivity extends NativeActivity {
    static {
        // The game's own natives resolve through this class loader.
        System.loadLibrary("horizon");
    }

    static native void nativeText(String text);

    /** The bytes of the image the skin picker returned. */
    static native void nativeSkin(byte[] image);

    private static final int PICK_SKIN = 42;

    /** Called by the game: the device's picker for a skin image. */
    public void pickSkin() {
        runOnUiThread(() -> {
            Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
            pick.setType("image/png");
            pick.addCategory(Intent.CATEGORY_OPENABLE);
            try {
                startActivityForResult(Intent.createChooser(pick, "Skin"), PICK_SKIN);
            } catch (RuntimeException e) {
                // No picker on this device.
            }
        });
    }

    private android.app.AlertDialog status;

    /** Called by the first start's preparing: its step, in a dialog over the black window. */
    public void showStatus(final String text) {
        runOnUiThread(() -> {
            if (status == null) {
                status = new android.app.AlertDialog.Builder(this)
                    .setTitle("MargyMC")
                    .setCancelable(false)
                    .setMessage(text)
                    .create();
                status.show();
            } else {
                status.setMessage(text);
            }
        });
    }

    static native void nativeChoice(int choice);

    static native void nativeName(String name);

    /** Called by the wardrobe: the player's name, edited in a dialog with the keyboard. */
    public void askName(final String current) {
        runOnUiThread(() -> {
            final android.widget.EditText field = new android.widget.EditText(this);
            field.setText(current);
            field.setSingleLine(true);
            field.setSelection(field.getText().length());
            field.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            field.setFilters(new android.text.InputFilter[] {
                new android.text.InputFilter.LengthFilter(16) });
            android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(this)
                .setTitle("Your name")
                .setMessage("3 to 16 letters, digits or _ (as on servers)")
                .setView(field)
                .setPositiveButton("OK", (d, w) -> nativeName(field.getText().toString().trim()))
                .setNegativeButton("Cancel", null)
                .create();
            dialog.getWindow().setSoftInputMode(
                android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
            dialog.show();
            field.requestFocus();
        });
    }

    /** Called by preparing: a question with two answers ("message\u001ffirst\u001fsecond"). */
    public void showChoice(final String text) {
        final String[] parts = text.split("\u001f", 3);
        runOnUiThread(() -> {
            if (status != null) {
                status.dismiss();
                status = null;
            }
            new android.app.AlertDialog.Builder(this)
                .setTitle("MargyMC")
                .setCancelable(false)
                .setMessage(parts[0])
                .setPositiveButton(parts.length > 1 ? parts[1] : "OK", (d, w) -> nativeChoice(0))
                .setNegativeButton(parts.length > 2 ? parts[2] : "Cancel", (d, w) -> nativeChoice(1))
                .show();
        });
    }

    /** Whether the app may read the phone's storage (/sdcard/MargyMC). */
    public boolean allFilesAccess() {
        return android.os.Build.VERSION.SDK_INT < 30
            || android.os.Environment.isExternalStorageManager();
    }

    /** Android's page that grants it. */
    public void askAllFilesAccess() {
        runOnUiThread(() -> {
            try {
                startActivity(new Intent(
                    android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    android.net.Uri.parse("package:" + getPackageName())));
            } catch (RuntimeException e) {
                startActivity(new Intent(
                    android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
            }
        });
    }

    /** Called once preparing is done: the app starts again, now with its resources. */
    public void restart() {
        runOnUiThread(() -> {
            Intent again = getPackageManager().getLaunchIntentForPackage(getPackageName());
            if (again != null) {
                again.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(again);
            }
            finishAffinity();
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(
                () -> android.os.Process.killProcess(android.os.Process.myPid()), 300);
        });
    }

    /** Called by the game: a page in the browser (the Microsoft sign-in). */
    public void openUrl(final String url) {
        runOnUiThread(() -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)));
            } catch (RuntimeException e) {
                // No browser.
            }
        });
    }

    /** Called by the game: text on the clipboard (the sign-in code). */
    public void copyText(final String text) {
        runOnUiThread(() -> {
            android.content.ClipboardManager clipboard =
                (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Horizon", text));
        });
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != PICK_SKIN || result != RESULT_OK || data == null || data.getData() == null) {
            return;
        }
        try (InputStream in = getContentResolver().openInputStream(data.getData())) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) > 0 && out.size() < 1 << 20) {
                out.write(buffer, 0, n);
            }
            nativeSkin(out.toByteArray());
        } catch (Exception e) {
            // Unreadable: nothing changes.
        }
    }

    /** An Android key code: KEYCODE_DEL or KEYCODE_ENTER. */
    static native void nativeKey(int code);

    private TextView input;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        input = new TextView(this);
        addContentView(input, new ViewGroup.LayoutParams(1, 1));
    }

    /** Called by the game when a text field gains or loses focus. */
    public void setKeyboard(final boolean show) {
        runOnUiThread(() -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (show) {
                input.reset();
                input.setFocusable(true);
                input.setFocusableInTouchMode(true);
                input.requestFocus();
                imm.restartInput(input);
                imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
            } else {
                imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
                input.clearFocus();
                input.setFocusable(false);
            }
        });
    }

    /** Takes the keyboard's edits and sends the game what changed. */
    static final class TextView extends View {
        private Connection connection;

        TextView(Context context) {
            super(context);
        }

        void reset() {
            if (connection != null) {
                connection.reset();
            }
        }

        @Override
        public boolean onCheckIsTextEditor() {
            return true;
        }

        @Override
        public InputConnection onCreateInputConnection(EditorInfo info) {
            info.inputType = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;
            // In landscape the keyboard covers the game's fields: its own full-screen editor
            // shows the text instead.
            info.imeOptions = EditorInfo.IME_ACTION_DONE;
            connection = new Connection(this);
            return connection;
        }
    }

    /** The keyboard's editor: its text since the field gained focus, mirrored as edits. */
    static final class Connection extends BaseInputConnection {
        private final View view;
        private String sent = "";
        /** The keyboard's full-screen editor follows the text (getExtractedText's monitor). */
        private int monitor = -1;

        Connection(View view) {
            super(view, true);
            this.view = view;
        }

        /** The field took the text (Enter) or changed: the keyboard starts over, so its
         *  editor shows no stale text. */
        void reset() {
            getEditable().clear();
            sent = "";
            monitor = -1;
            InputMethodManager imm = (InputMethodManager) view.getContext()
                .getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.restartInput(view);
        }

        private ExtractedText extracted() {
            android.text.Editable editable = getEditable();
            ExtractedText text = new ExtractedText();
            text.text = editable.toString();
            text.startOffset = 0;
            text.selectionStart = Math.max(0, android.text.Selection.getSelectionStart(editable));
            text.selectionEnd = Math.max(0, android.text.Selection.getSelectionEnd(editable));
            return text;
        }

        /** The keyboard's view of the editor: the selection and the word being composed as
         *  they are, so its own editor shows the text once (not "gag" for "ga"). */
        private void report() {
            InputMethodManager imm = (InputMethodManager) view.getContext()
                .getSystemService(Context.INPUT_METHOD_SERVICE);
            android.text.Editable editable = getEditable();
            int start = android.text.Selection.getSelectionStart(editable);
            int end = android.text.Selection.getSelectionEnd(editable);
            imm.updateSelection(view, start, end, getComposingSpanStart(editable),
                getComposingSpanEnd(editable));
            if (monitor >= 0) {
                imm.updateExtractedText(view, monitor, extracted());
            }
        }

        @Override
        public ExtractedText getExtractedText(ExtractedTextRequest request, int flags) {
            if ((flags & GET_EXTRACTED_TEXT_MONITOR) != 0 && request != null) {
                monitor = request.token;
            }
            return extracted();
        }

        /** Backspaces to the common start, then the rest of the new text. */
        private void sync() {
            String now = getEditable().toString();
            int common = 0;
            int max = Math.min(now.length(), sent.length());
            while (common < max && now.charAt(common) == sent.charAt(common)) {
                common++;
            }
            int deleted = sent.codePointCount(common, sent.length());
            for (int i = 0; i < deleted; i++) {
                nativeKey(KeyEvent.KEYCODE_DEL);
            }
            if (common < now.length()) {
                nativeText(now.substring(common));
            }
            sent = now;
            report();
        }

        @Override
        public boolean commitText(CharSequence text, int position) {
            boolean done = super.commitText(text, position);
            sync();
            return done;
        }

        @Override
        public boolean setComposingText(CharSequence text, int position) {
            boolean done = super.setComposingText(text, position);
            sync();
            return done;
        }

        @Override
        public boolean finishComposingText() {
            boolean done = super.finishComposingText();
            sync();
            return done;
        }

        @Override
        public boolean deleteSurroundingText(int before, int after) {
            if (before > 0 && getEditable().length() == 0) {
                for (int i = 0; i < before; i++) {
                    nativeKey(KeyEvent.KEYCODE_DEL);
                }
                return true;
            }
            boolean done = super.deleteSurroundingText(before, after);
            sync();
            return done;
        }

        @Override
        public boolean sendKeyEvent(KeyEvent event) {
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                int code = event.getKeyCode();
                if (code == KeyEvent.KEYCODE_DEL) {
                    if (getEditable().length() > 0) {
                        int end = getEditable().length();
                        getEditable().delete(end - 1, end);
                        sync();
                    } else {
                        nativeKey(KeyEvent.KEYCODE_DEL);
                    }
                    return true;
                }
                if (code == KeyEvent.KEYCODE_ENTER) {
                    nativeKey(KeyEvent.KEYCODE_ENTER);
                    reset();
                    return true;
                }
                int unicode = event.getUnicodeChar();
                if (unicode != 0) {
                    getEditable().append(new String(Character.toChars(unicode)));
                    sync();
                    return true;
                }
            }
            return event.getAction() == KeyEvent.ACTION_UP || super.sendKeyEvent(event);
        }

        @Override
        public boolean performEditorAction(int action) {
            nativeKey(KeyEvent.KEYCODE_ENTER);
            reset();
            return true;
        }
    }
}
