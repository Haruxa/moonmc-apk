#!/usr/bin/env bash
# Встроенный бенчмарк игры на телефоне: android/bench.sh <serial> <scene> <resolutionScale> [render distance]
# Настройки игрока сохраняются и возвращаются. Отчёт кладётся в android/out/bench-<scene>-<scale>.json
set -euo pipefail
S=$1; SCENE=$2; SCALE=$3; RD=${4:-12}; PACK=${5:-}
ADB=~/platform-tools/adb; PKG=cat.narezany.horizon
cd "$(dirname "$0")/.."
sh_as() { "$ADB" -s "$S" shell run-as $PKG "$@"; }
sh_as cp files/horizon-graphics.txt files/horizon-graphics.txt.bak
sh_as sed -i "s/^resolutionScale:.*/resolutionScale:$SCALE/" files/horizon-graphics.txt
[ -n "$PACK" ] && sh_as sed -i "s/^pickedShaderPack:.*/pickedShaderPack:$PACK/" files/horizon-graphics.txt
echo "--benchmark $SCENE --render-distance $RD" | "$ADB" -s "$S" exec-in run-as $PKG sh -c 'cat > files/args.txt'
sh_as rm -rf files/benchmarks
"$ADB" -s "$S" shell am force-stop $PKG
"$ADB" -s "$S" shell am start -n $PKG/.HorizonActivity >/dev/null
for i in $(seq 1 120); do
    sleep 3
    "$ADB" -s "$S" shell pidof $PKG >/dev/null || break
done
sh_as rm -f files/args.txt
sh_as mv files/horizon-graphics.txt.bak files/horizon-graphics.txt
REPORT=$(sh_as ls files/benchmarks | head -1)
sh_as cat "files/benchmarks/$REPORT" > "android/out/bench-$SCENE-$SCALE.json"
python3 -I - "android/out/bench-$SCENE-$SCALE.json" <<'PY'
import json, sys
r = json.load(open(sys.argv[1]))
def walk(o, path=""):
    if isinstance(o, dict):
        for k, v in o.items():
            yield from walk(v, f"{path}.{k}" if path else k)
    elif isinstance(o, list):
        for i, v in enumerate(o):
            yield from walk(v, f"{path}[{i}]")
    else:
        yield path, o
for k, v in walk(r):
    if any(w in k.lower() for w in ("fps", "median", "p99", "gpu", "cpu_ms", "frame_ms", "resolution", "render_distance", "width", "height", "chunk_load")):
        print(f"{k} = {v}")
PY
