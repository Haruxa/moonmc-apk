#!/usr/bin/env bash
# Собирает libhorizon.so и apk: android/out/horizon.apk
# PROFILE=fast (по умолчанию) или release
set -euo pipefail
cd "$(dirname "$0")/.."
source android/env.sh
PROFILE=${PROFILE:-fast}
OUT=android/out
mkdir -p "$OUT" android/keys
cargo build --profile "$PROFILE" --target aarch64-linux-android -p horizon-android
SO=target/aarch64-linux-android/$PROFILE/libhorizon.so

rm -rf "$OUT/stage" "$OUT/res.zip" "$OUT/assets" && mkdir -p "$OUT/stage/lib/arm64-v8a"
"$NDK_BIN/llvm-strip" --strip-debug -o "$OUT/stage/lib/arm64-v8a/libhorizon.so" "$SO"

# HorizonActivity (the soft keyboard's text): javac, then d8 to classes.dex
rm -rf "$OUT/classes" && mkdir -p "$OUT/classes" "$OUT/dex"
"$JAVA_HOME/bin/javac" -source 8 -target 8 -nowarn -Xlint:-options \
    -classpath "$ANDROID_HOME/platforms/android-35/android.jar" -d "$OUT/classes" \
    $(find android/java -name '*.java')
PATH="$JAVA_HOME/bin:$PATH" "$BUILD_TOOLS/d8" --min-api 29 --lib "$ANDROID_HOME/platforms/android-35/android.jar" \
    --output "$OUT/dex" $(find "$OUT/classes" -name '*.class')

# java и javac для подготовки ресурсов на телефоне: программа в папке библиотек
(cd android/java-launcher && cargo build --release --target aarch64-linux-android -q)
LAUNCHER=android/java-launcher/target/aarch64-linux-android/release/horizon-java-launcher
cp "$LAUNCHER" "$OUT/stage/lib/arm64-v8a/libhorizonjava.so"
cp "$LAUNCHER" "$OUT/stage/lib/arm64-v8a/libhorizonjavac.so"
cp "$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/lib/aarch64-linux-android/libc++_shared.so" \
    "$OUT/stage/lib/arm64-v8a/"

# assets: Java-рантайм Zalith Launcher 2 (OpenJDK 25, GPLv2 + Classpath Exception) по коммиту и sha256,
# и экспортёры Horizon (исходники, классы, research-lock.json). Ничего от Mojang.
CACHE=android/cache
mkdir -p "$CACHE" "$OUT/assets/jre"
JRE_URL=https://raw.githubusercontent.com/ZalithLauncher/ZalithLauncher2/fa4103be9b69ab81d49b459b9477d38af397f038/ZalithLauncher/src/main/assets/runtimes/jre-25
for entry in "universal.tar.xz 23141bf4e0ed46ff0b751c6cc32b3863d39e6a37b720f3d86a4fe9318aeb8e9f" \
             "bin-arm64.tar.xz 16f09d1d163c008ae556be68c624057c4791c21ae6d31302334e61d75439567b"; do
    set -- $entry
    [ -f "$CACHE/$1" ] || curl -fsSL -o "$CACHE/$1" "$JRE_URL/$1"
    echo "$2  $CACHE/$1" | sha256sum -c --quiet
    cp "$CACHE/$1" "$OUT/assets/jre/$1"
done
KEY=$(ls .local/exporters | head -1)
python3 -I - "$OUT/assets/prepare.zip" ".local/exporters/$KEY" <<'PY'
import os, sys, zipfile
out, exporters = sys.argv[1], sys.argv[2]
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    z.write("research-lock.json", "research-lock.json")
    parity = "mods/horizon/src/test/java/dev/horizonlab/parity"
    for base, _, files in os.walk(parity):
        for f in files:
            p = os.path.join(base, f)
            z.write(p, p)
    for base, _, files in os.walk(exporters):
        for f in files:
            if f.endswith(".log"):
                continue
            p = os.path.join(base, f)
            z.write(p, os.path.join("exporters", os.path.relpath(p, exporters)))
PY

"$BUILD_TOOLS/aapt2" compile --dir android/res -o "$OUT/res.zip"
"$BUILD_TOOLS/aapt2" link -o "$OUT/base.apk" -I "$ANDROID_HOME/platforms/android-35/android.jar" \
    --manifest android/AndroidManifest.xml -A "$OUT/assets" "$OUT/res.zip"
# библиотеки сжаты: extractNativeLibs=true распаковывает их при установке (java нужен файлом)
python3 -I -c 'import sys, zipfile, os
with zipfile.ZipFile(sys.argv[1], "a") as z:
    stage = sys.argv[2]
    for f in sorted(os.listdir(stage)):
        z.write(os.path.join(stage, f), "lib/arm64-v8a/" + f, zipfile.ZIP_DEFLATED)
    z.write(sys.argv[3], "classes.dex", zipfile.ZIP_DEFLATED)' "$OUT/base.apk" "$OUT/stage/lib/arm64-v8a" "$OUT/dex/classes.dex"

if [ ! -f android/keys/horizon.jks ]; then
    head -c 24 /dev/urandom | base64 | tr -d '/+=' > android/keys/pass
    chmod 600 android/keys/pass
    "$JAVA_HOME/bin/keytool" -genkeypair -keystore android/keys/horizon.jks -alias horizon -keyalg RSA \
        -keysize 2048 -validity 10000 -storepass "$(cat android/keys/pass)" -dname "CN=horizon" >/dev/null 2>&1
fi
"$BUILD_TOOLS/zipalign" -f -P 16 4 "$OUT/base.apk" "$OUT/aligned.apk"
PATH="$JAVA_HOME/bin:$PATH" "$BUILD_TOOLS/apksigner" sign --ks android/keys/horizon.jks --ks-key-alias horizon \
    --ks-pass file:android/keys/pass --out "$OUT/horizon.apk" "$OUT/aligned.apk"
rm -f "$OUT/base.apk" "$OUT/aligned.apk" "$OUT/horizon.apk.idsig" "$OUT/res.zip"
ls -la "$OUT/horizon.apk"
