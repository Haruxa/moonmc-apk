#!/usr/bin/env bash
# Мигание мира: стоим в тестовом мире, пишем экран, ищем кадры, сильно отличающиеся от соседних.
# android/flicker-test.sh <serial> <HORIZON_GPU_CULL: 0|shader|early> [ожидание, с]
set -euo pipefail
S=$1; CULL=$2; WAIT=${3:-35}
ADB=~/platform-tools/adb; PKG=cat.narezany.horizon
OUT=$(mktemp -d)
run_as() { "$ADB" -s "$S" exec-in run-as $PKG sh -c "$1"; }
echo "--world FlickerTest --creative --seed 7" | run_as 'cat > files/args.txt'
if [ "$CULL" = early ]; then printf '' ; else printf 'HORIZON_GPU_CULL=%s\n' "$CULL"; fi | run_as 'cat > files/env.txt'
[ "$CULL" = early ] && echo "HORIZON_GPU_CULL=1" | run_as 'cat > files/env.txt'
"$ADB" -s "$S" shell am force-stop $PKG
"$ADB" -s "$S" shell am start -n $PKG/android.app.NativeActivity >/dev/null
"$ADB" -s "$S" shell "sleep $WAIT"
"$ADB" -s "$S" shell screenrecord --time-limit 6 --size 1400x630 --bit-rate 24000000 /data/local/tmp/flicker.mp4
"$ADB" -s "$S" pull -q /data/local/tmp/flicker.mp4 "$OUT/f.mp4"
"$ADB" -s "$S" shell rm /data/local/tmp/flicker.mp4
"$ADB" -s "$S" shell run-as $PKG rm -f files/args.txt files/env.txt
"$ADB" -s "$S" shell run-as $PKG cat files/logs/latest.log | grep -E "pipelines ready|ERROR" | cut -c1-160 | head -5
ffmpeg -loglevel error -i "$OUT/f.mp4" -vf "tblend=all_mode=difference,signalstats,metadata=print:key=lavfi.signalstats.YAVG:file=$OUT/d.txt" -f null -
python3 -I - "$OUT/d.txt" <<'PY'
import sys, re
v=[float(m) for m in re.findall(r"YAVG=([0-9.]+)", open(sys.argv[1]).read())]
if not v: print("no frames"); sys.exit()
s=sorted(v); med=s[len(s)//2]
spikes=[x for x in v if x > max(3*med, med+2)]
print(f"frames {len(v)+1}, median diff {med:.2f}, max {max(v):.2f}, spikes {len(spikes)}")
PY
cp "$OUT/f.mp4" "/tmp/claude-1000/flicker-$CULL.mp4" 2>/dev/null || true
rm -rf "$OUT"
