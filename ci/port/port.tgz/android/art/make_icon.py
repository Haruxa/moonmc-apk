"""MargyMC's icon: a grass block drawn flat, white and pale mint on MargyT's mint.

    python3 android/art/make_icon.py

Writes margymc-1024.png (the whole icon, rounded), margymc-foreground-432.png (the
block alone for the adaptive icon's front, in its 66% safe zone) and the
mipmap PNGs under android/res.
"""
import os
from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "..", "res")
MINT = (141, 209, 176)
TOP = (255, 255, 255)
LEFT = (206, 239, 223)
RIGHT = (172, 224, 199)
EDGE = (110, 182, 149)
# How far the top's grass hangs down each side, column by column (of the face's height).
DRIP = [0.20, 0.30, 0.18, 0.26, 0.34, 0.20, 0.28, 0.17]


def block(size, scale):
    """The block alone on nothing, `scale` of `size` tall, drawn 4x and scaled down."""
    k = 4
    n = size * k
    img = Image.new("RGBA", (n, n), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    s = n * scale / 2
    cx, cy = n / 2, n / 2 - s * 0.0
    c30 = 0.8660254
    top = (cx, cy - s)
    left_top = (cx - s * c30, cy - s / 2)
    right_top = (cx + s * c30, cy - s / 2)
    centre = (cx, cy)
    bottom = (cx, cy + s)
    left_bottom = (cx - s * c30, cy + s / 2)
    right_bottom = (cx + s * c30, cy + s / 2)
    d.polygon([left_top, centre, bottom, left_bottom], fill=LEFT)
    d.polygon([centre, right_top, right_bottom, bottom], fill=RIGHT)
    d.polygon([top, right_top, centre, left_top], fill=TOP)

    def face(origin, along, u, v):
        return (origin[0] + along[0] * u, origin[1] + along[1] * u + s * v)

    for origin, along, drips in [
        (left_top, (centre[0] - left_top[0], centre[1] - left_top[1]), DRIP),
        (centre, (right_top[0] - centre[0], right_top[1] - centre[1]), DRIP[::-1]),
    ]:
        cols = len(drips)
        for i, depth in enumerate(drips):
            u0, u1 = i / cols, (i + 1) / cols
            d.polygon(
                [face(origin, along, u0, 0), face(origin, along, u1, 0),
                 face(origin, along, u1, depth), face(origin, along, u0, depth)],
                fill=TOP,
            )
    # The edges between the faces, thin, as a soft outline would be.
    w = max(1, int(n * 0.006))
    d.line([left_top, centre, right_top], fill=EDGE + (90,), width=w)
    d.line([centre, bottom], fill=EDGE + (90,), width=w)
    return img.resize((size, size), Image.LANCZOS)


def icon(size):
    bg = Image.new("RGBA", (size, size), MINT + (255,))
    bg.alpha_composite(block(size, 0.62))
    mask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, size - 1, size - 1), radius=int(size * 0.22), fill=255)
    out = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    out.paste(bg, (0, 0), mask)
    return out


if __name__ == "__main__":
    icon(1024).save(os.path.join(HERE, "margymc-1024.png"))
    # Adaptive icon: 108 dp, the front's safe zone the middle 66.
    block(432, 0.5).save(os.path.join(HERE, "margymc-foreground-432.png"))
    for folder, px in [("mipmap-xhdpi", 96), ("mipmap-xxhdpi", 144), ("mipmap-xxxhdpi", 192)]:
        os.makedirs(os.path.join(RES, folder), exist_ok=True)
        icon(px).save(os.path.join(RES, folder, "ic_launcher.png"))
    for folder, px in [("drawable-xxxhdpi", 432)]:
        os.makedirs(os.path.join(RES, folder), exist_ok=True)
        block(px, 0.5).save(os.path.join(RES, folder, "ic_launcher_foreground.png"))
