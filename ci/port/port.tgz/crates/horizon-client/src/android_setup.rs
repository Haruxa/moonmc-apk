//! Horizon on Android: preparing the resources on the phone, from the player's own copy of
//! Minecraft 26.3, when the game folder has none (the first start). It runs before the game's
//! event loop, in a mode of its own: a thread prepares while this one keeps the activity
//! answering, a dialog shows the steps, and the app starts again once it is done.
//!
//! The APK carries what it takes and nothing of Mojang's: Zalith Launcher 2's OpenJDK 25 for
//! Android (`assets/jre/*.tar.xz`, GPLv2 with the Classpath Exception), Horizon's exporters
//! (`assets/prepare.zip`: research-lock.json, their sources and their classes), and `java` and
//! `javac` as programs in the library folder (`libhorizonjava.so`, `libhorizonjavac.so`).
use std::ffi::CString;
use std::io::Read;
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex};
use std::time::Duration;
use winit::platform::android::activity::{AndroidApp, MainEvent, PollEvent};

/// The resources the game reads (game.rs's default `--resources`).
const RESOURCES: &str = ".local/horizon-client/26.3";
/// The Minecraft the app downloaded, in its private folder.
const MINECRAFT: &str = "minecraft";
/// The Minecraft folder a player copies over: on the phone's storage, where any file manager
/// and a computer over USB reach it (the app asks for access to all files to read it).
const PUBLIC: &str = "/sdcard/MargyMC/minecraft";
/// The pinned version.
const VERSION: &str = "26.3";

/// The resources are prepared.
pub fn prepared(home: &Path) -> bool {
    home.join(RESOURCES).join("horizon-resources.json").is_file()
}

/// The setup mode: returns when the app should start again (prepared) or stop.
pub fn run(app: &AndroidApp, home: &Path, status: fn(&str), restart: fn()) {
    let shared = Arc::new(Mutex::new((String::new(), None::<bool>)));
    let set = {
        let shared = shared.clone();
        move |text: &str| {
            if let Ok(mut s) = shared.lock() {
                s.0 = text.to_owned();
            }
        }
    };
    let library = library_dir();
    let assets = app.asset_manager();
    // The archives in the APK, read here: the asset manager stays on this thread.
    let read_asset = |name: &str| -> Option<Vec<u8>> {
        let name = CString::new(name).ok()?;
        let mut asset = assets.open(&name)?;
        let mut bytes = Vec::new();
        asset.read_to_end(&mut bytes).ok()?;
        Some(bytes)
    };
    let jre = home.join("jre");
    let mut archives = Vec::new();
    if !jre.join("release").is_file() {
        set("Unpacking Java...");
        status("Unpacking Java...");
        for name in ["jre/universal.tar.xz", "jre/bin-arm64.tar.xz"] {
            archives.push(read_asset(name));
        }
    }
    let kit = read_asset("prepare.zip");
    let home = home.to_path_buf();
    let worker = {
        let shared = shared.clone();
        std::thread::Builder::new()
            .name("Prepare".into())
            .spawn(move || {
                let log = |text: &str| {
                    log::info!("Prepare: {text}");
                    set(text);
                };
                let result = setup(&home, &jre, archives, kit, library, &log);
                if let Err(e) = &result {
                    log::error!("Prepare failed: {e}");
                    set(&format!("Preparing failed:\n{e}"));
                }
                if let Ok(mut s) = shared.lock() {
                    s.1 = Some(result.is_ok());
                }
            })
    };
    if worker.is_err() {
        status("Could not start preparing.");
        return;
    }
    let mut shown = String::new();
    loop {
        let mut destroyed = false;
        app.poll_events(Some(Duration::from_millis(200)), |event| {
            if let PollEvent::Main(MainEvent::Destroy) = event {
                destroyed = true;
            }
        });
        if destroyed {
            return;
        }
        let (text, done) = shared
            .lock()
            .map(|s| s.clone())
            .unwrap_or_else(|e| e.into_inner().clone());
        if text != shown {
            status(&text);
            shown = text;
        }
        match done {
            Some(true) => {
                status("Ready. Starting MargyMC...");
                std::thread::sleep(Duration::from_millis(800));
                restart();
                return;
            }
            // The message stays until the player closes the app.
            Some(false) => {}
            None => {}
        }
    }
}

/// The folder Android unpacked the app's libraries to (this library's own folder).
fn library_dir() -> Option<PathBuf> {
    let maps = std::fs::read_to_string("/proc/self/maps").ok()?;
    maps.lines()
        .filter_map(|line| line.split_whitespace().nth(5))
        .find(|path| path.ends_with("/libhorizon.so"))
        .and_then(|path| Path::new(path).parent().map(Path::to_path_buf))
}

fn setup(
    home: &Path,
    jre: &Path,
    archives: Vec<Option<Vec<u8>>>,
    kit: Option<Vec<u8>>,
    library: Option<PathBuf>,
    log: &dyn Fn(&str),
) -> Result<(), String> {
    let library = library.ok_or("The app's library folder was not found.")?;
    // Java, once.
    if !archives.is_empty() {
        let _ = std::fs::remove_dir_all(jre);
        std::fs::create_dir_all(jre).map_err(|e| e.to_string())?;
        for archive in archives {
            let archive = archive.ok_or("This build has no Java runtime.")?;
            let mut tar = Vec::new();
            lzma_rs::xz_decompress(&mut archive.as_slice(), &mut tar)
                .map_err(|e| format!("Java runtime: {e}"))?;
            tar::Archive::new(tar.as_slice())
                .unpack(jre)
                .map_err(|e| format!("Java runtime: {e}"))?;
        }
    }
    // Horizon's exporters (sources, classes, research-lock.json): every start, they are small.
    log("Unpacking Horizon's exporters...");
    let kit = kit.ok_or("This build has no exporters.")?;
    let mut zip = zip::ZipArchive::new(std::io::Cursor::new(kit)).map_err(|e| e.to_string())?;
    zip.extract(home).map_err(|e| e.to_string())?;
    let minecraft = find_minecraft(home, log)?;
    let server_jar = Some(minecraft.join("server.jar")).filter(|p| p.is_file());
    let cache = home.join("tmp");
    let _ = std::fs::create_dir_all(&cache);
    let path = |name: &str| library.join(name).to_string_lossy().into_owned();
    // The environment of the preparer's Java processes. The folder with libjvm.so goes first:
    // the launcher re-executes itself when LD_LIBRARY_PATH holds a libjvm.so anywhere else,
    // and on Android it re-executes $JAVA_HOME/bin/java, which the data folder may not run.
    let ld = format!(
        "{}:{}:{}",
        jre.join("lib/server").display(),
        jre.join("lib").display(),
        library.display()
    );
    let env = [
        ("JAVA_HOME", jre.to_string_lossy().into_owned()),
        ("HORIZON_JAVA", path("libhorizonjava.so")),
        ("HORIZON_JAVAC", path("libhorizonjavac.so")),
        ("LD_LIBRARY_PATH", ld),
        ("TMPDIR", cache.to_string_lossy().into_owned()),
        (
            "JDK_JAVA_OPTIONS",
            format!("-Djava.io.tmpdir={} -Djava.awt.headless=true", cache.display()),
        ),
    ];
    crate::set_env(&env);
    let options = horizon_prepare::Options {
        root: home.to_path_buf(),
        import: true,
        minecraft_dir: Some(minecraft.clone()),
        server_jar,
        java_home: Some(jre.to_path_buf()),
    };
    log("Preparing the resources from your Minecraft (a few minutes)...");
    horizon_prepare::prepare(&options, log)?;
    // The sounds are optional: a failure leaves the game silent, not broken.
    if let Err(e) = horizon_prepare::sounds(home, Some(&minecraft), log) {
        log::warn!("Prepare: no sounds: {e}");
    }
    Ok(())
}

/// A folder with the pinned version's client: the version file and the jar.
fn has_version(dir: &Path) -> bool {
    let v = dir.join("versions").join(VERSION);
    v.join(format!("{VERSION}.json")).is_file() && v.join(format!("{VERSION}.jar")).is_file()
}

/// The player's own Minecraft 26.3: one downloaded before, else the public folder, else, with a
/// Microsoft app in this build, the player's choice of a download (signed in with the account
/// that owns the game) or the folder.
fn find_minecraft(home: &Path, log: &dyn Fn(&str)) -> Result<PathBuf, String> {
    let downloaded = home.join(MINECRAFT);
    let public = PathBuf::from(PUBLIC);
    let mut folder = horizon_client::msa::client_id().is_none();
    let mut asked_access = false;
    loop {
        if has_version(&downloaded) {
            return Ok(downloaded);
        }
        if crate::all_files_access() && has_version(&public) {
            return Ok(public);
        }
        if !folder {
            // Download or folder.
            match crate::choose(
                "MargyMC needs your own Minecraft: Java Edition 26.3.\n\n\
                 Download it from Mojang, signing in with the Microsoft account that owns it, \
                 or copy your Minecraft folder to the phone yourself?",
                "Download",
                "Use a folder",
            ) {
                0 => match download(home, &downloaded, log) {
                    Ok(()) => continue,
                    Err(e) => {
                        log(&format!("Downloading failed:\n{e}"));
                        std::thread::sleep(Duration::from_secs(4));
                        continue;
                    }
                },
                _ => folder = true,
            }
        }
        if !crate::all_files_access() {
            if !asked_access {
                asked_access = true;
                crate::ask_all_files_access();
            }
            log(&format!(
                "Allow MargyMC to access all files, to read your Minecraft from\n{PUBLIC}\n\n\
                 Waiting for the permission..."
            ));
            std::thread::sleep(Duration::from_secs(2));
            continue;
        }
        if std::fs::create_dir_all(&public).is_ok() {
            let _ = std::fs::write(
                public.join("README.txt"),
                "Put your own Minecraft: Java Edition 26.3 here, from a computer or a launcher \
                 that has played it:\n\n  versions/26.3/26.3.json and 26.3.jar\n  libraries/\n  \
                 assets/ (indexes and objects)\n  server.jar (the 26.3 server)\n\n\
                 MargyMC prepares its resources from them once.\n",
            );
        }
        log(&format!(
            "Copy your own Minecraft: Java Edition 26.3 to\n{PUBLIC}\n\n\
             versions/26.3, libraries and assets from a Minecraft folder that has played 26.3, \
             and the 26.3 server jar as server.jar.\n\nWaiting for it..."
        ));
        std::thread::sleep(Duration::from_secs(3));
    }
}

/// The signed-in account (signing in here when there is none), then the download.
fn download(home: &Path, dir: &Path, log: &dyn Fn(&str)) -> Result<(), String> {
    use horizon_client::msa;
    let client_id = msa::client_id().ok_or("This build has no Microsoft app (client ID).")?;
    if msa::load().is_none() {
        let ep = msa::Endpoints::live();
        let code = msa::device_code(&ep, &client_id)?;
        crate::copy_text(&code.user_code);
        crate::open_url(&code.verification_uri);
        log(&format!(
            "Sign in with the Microsoft account that owns Minecraft: Java Edition.\n\n\
             Open {}\nand enter the code (it is copied):\n\n{}\n\nWaiting for the sign-in...",
            code.verification_uri, code.user_code
        ));
        let tokens = msa::wait_for_sign_in(&ep, &client_id, &code, &|| false)?;
        log("Checking that the account owns the game...");
        // finish_sign_in refuses an account that doesn't own Minecraft: Java Edition.
        let (account, secrets) = msa::finish_sign_in(&ep, tokens)?;
        msa::save(&account, &secrets)?;
    }
    let lock: serde_json::Value = serde_json::from_slice(
        &std::fs::read(home.join("research-lock.json")).map_err(|e| e.to_string())?,
    )
    .map_err(|e| e.to_string())?;
    let manifest = lock["minecraft"]["manifest_sha1"]
        .as_str()
        .ok_or("research-lock.json pins no version file")?;
    crate::android_download::download(dir, VERSION, manifest, log)
}
