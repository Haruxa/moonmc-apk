//! Horizon on Android: the entry point a NativeActivity calls (`crates/horizon-android` builds
//! this file into libhorizon.so). The game is main.rs's own `mod game`.
#![deny(unsafe_code)]
mod android_download;
mod android_setup;
mod game;

use horizon_client::{crash, logging};
use std::ffi::{CString, c_char, c_int};
use std::io::{BufRead, BufReader};
use std::os::fd::{FromRawFd, OwnedFd};
use winit::platform::android::activity::AndroidApp;

#[allow(unsafe_code)]
#[link(name = "log")]
unsafe extern "C" {
    fn __android_log_write(prio: c_int, tag: *const c_char, text: *const c_char) -> c_int;
}

/// stdout and stderr go nowhere in an app: send them to logcat (tag `horizon`).
#[allow(unsafe_code)]
fn forward_output() {
    let mut fds = [0 as c_int; 2];
    // SAFETY: a fresh pipe whose write end replaces fds 1 and 2, its read end owned below.
    unsafe {
        if libc::pipe(fds.as_mut_ptr()) != 0 {
            return;
        }
        libc::dup2(fds[1], 1);
        libc::dup2(fds[1], 2);
        libc::close(fds[1]);
    }
    // SAFETY: fds[0] is the pipe's read end, owned by nothing else.
    let read = unsafe { OwnedFd::from_raw_fd(fds[0]) };
    let _ = std::thread::Builder::new()
        .name("logcat".into())
        .spawn(move || {
            let tag = c"horizon";
            for line in BufReader::new(std::fs::File::from(read)).lines() {
                let Ok(line) = line else { break };
                let text = CString::new(line.replace('\0', " ")).unwrap_or_default();
                // SAFETY: both strings are NUL-terminated and live for the call. 4 = INFO.
                unsafe { __android_log_write(4, tag.as_ptr(), text.as_ptr()) };
            }
        });
}

/// HorizonActivity.nativeText: text the soft keyboard typed.
#[allow(unsafe_code)]
#[unsafe(no_mangle)]
extern "system" fn Java_cat_narezany_horizon_HorizonActivity_nativeText(
    mut env: jni::JNIEnv,
    _: jni::objects::JClass,
    text: jni::objects::JString,
) {
    if let Ok(text) = env.get_string(&text) {
        horizon_client::event_loop::push_typed(horizon_client::event_loop::Typed::Text(
            text.into(),
        ));
    }
}

/// HorizonActivity.nativeSkin: the bytes of the image the picker returned.
#[allow(unsafe_code)]
#[unsafe(no_mangle)]
extern "system" fn Java_cat_narezany_horizon_HorizonActivity_nativeSkin(
    env: jni::JNIEnv,
    _: jni::objects::JClass,
    bytes: jni::objects::JByteArray,
) {
    if let Ok(bytes) = env.convert_byte_array(&bytes) {
        horizon_client::event_loop::push_picked(bytes);
    }
}

/// HorizonActivity.nativeKey: KEYCODE_DEL (67) or KEYCODE_ENTER (66).
#[allow(unsafe_code)]
#[unsafe(no_mangle)]
extern "system" fn Java_cat_narezany_horizon_HorizonActivity_nativeKey(
    _: jni::JNIEnv,
    _: jni::objects::JClass,
    code: jni::sys::jint,
) {
    use horizon_client::event_loop::{Typed, push_typed};
    match code {
        67 => push_typed(Typed::Backspace),
        66 => push_typed(Typed::Enter),
        _ => {}
    }
}

/// The VM and the activity (HorizonActivity) as android-activity gives them; ndk-context holds
/// the Application instead.
static JAVA: std::sync::OnceLock<(usize, usize)> = std::sync::OnceLock::new();

/// The process's environment (android_setup.rs: the preparer's Java), before any other thread
/// of the game reads it.
#[allow(unsafe_code)]
fn set_env(vars: &[(&str, String)]) {
    for (key, value) in vars {
        // SAFETY: set while only the preparing thread runs; the game has not started.
        unsafe { std::env::set_var(key, value) };
    }
}

/// HorizonActivity.showStatus: the setup's dialog.
fn show_status(text: &str) {
    call_activity("showStatus", "(Ljava/lang/String;)V", Some(text));
}

/// HorizonActivity.restart: the app again, from the start.
fn restart() {
    call_activity("restart", "()V", None);
}

/// The answer to `choose`'s dialog: the button's index, -1 while there is none.
static CHOICE: std::sync::atomic::AtomicI32 = std::sync::atomic::AtomicI32::new(-1);

/// HorizonActivity.nativeChoice: a button of `showChoice`'s dialog.
#[allow(unsafe_code)]
#[unsafe(no_mangle)]
extern "system" fn Java_cat_narezany_horizon_HorizonActivity_nativeChoice(
    _: jni::JNIEnv,
    _: jni::objects::JClass,
    choice: jni::sys::jint,
) {
    CHOICE.store(choice, std::sync::atomic::Ordering::SeqCst);
}

/// A question with two answers in a dialog; waits for the player and returns 0 or 1.
fn choose(message: &str, first: &str, second: &str) -> i32 {
    use std::sync::atomic::Ordering::SeqCst;
    CHOICE.store(-1, SeqCst);
    let text = format!("{message}\u{1f}{first}\u{1f}{second}");
    call_activity("showChoice", "(Ljava/lang/String;)V", Some(&text));
    loop {
        let choice = CHOICE.load(SeqCst);
        if choice >= 0 {
            return choice;
        }
        std::thread::sleep(std::time::Duration::from_millis(100));
    }
}

/// HorizonActivity.allFilesAccess: the app may read the phone's storage (/sdcard/MargyMC).
#[allow(unsafe_code)]
fn all_files_access() -> bool {
    let Some(&(vm, activity)) = JAVA.get() else {
        return false;
    };
    // SAFETY: the process's VM, which lives as long as it.
    let Ok(vm) = (unsafe { jni::JavaVM::from_raw(vm as *mut jni::sys::JavaVM) }) else {
        return false;
    };
    let Ok(mut env) = vm.attach_current_thread() else {
        return false;
    };
    // SAFETY: the activity's global reference, held by the NativeActivity while it lives.
    let activity = unsafe { jni::objects::JObject::from_raw(activity as jni::sys::jobject) };
    match env
        .call_method(&activity, "allFilesAccess", "()Z", &[])
        .and_then(|v| v.z())
    {
        Ok(granted) => granted,
        Err(_) => {
            let _ = env.exception_clear();
            false
        }
    }
}

/// HorizonActivity.askAllFilesAccess: Android's page for the permission.
fn ask_all_files_access() {
    call_activity("askAllFilesAccess", "()V", None);
}

/// HorizonActivity.nativeName: the name the name dialog gave back.
#[allow(unsafe_code)]
#[unsafe(no_mangle)]
extern "system" fn Java_cat_narezany_horizon_HorizonActivity_nativeName(
    mut env: jni::JNIEnv,
    _: jni::objects::JClass,
    name: jni::objects::JString,
) {
    if let Ok(name) = env.get_string(&name) {
        horizon_client::event_loop::push_name(name.into());
    }
}

/// HorizonActivity.askName: a dialog for the player's name.
fn ask_name(current: &str) {
    call_activity("askName", "(Ljava/lang/String;)V", Some(current));
}

/// HorizonActivity.pickSkin: the device's picker for an image.
fn pick_skin() {
    call_activity("pickSkin", "()V", None);
}

/// HorizonActivity.openUrl: the page in the browser.
fn open_url(url: &str) {
    call_activity("openUrl", "(Ljava/lang/String;)V", Some(url));
}

/// HorizonActivity.copyText: the text on the clipboard.
fn copy_text(text: &str) {
    call_activity("copyText", "(Ljava/lang/String;)V", Some(text));
}

/// A void method of HorizonActivity with no argument or one string, from the game's thread.
#[allow(unsafe_code)]
fn call_activity(name: &str, signature: &str, text: Option<&str>) {
    let Some(&(vm, activity)) = JAVA.get() else {
        return;
    };
    // SAFETY: the process's VM, which lives as long as it.
    let Ok(vm) = (unsafe { jni::JavaVM::from_raw(vm as *mut jni::sys::JavaVM) }) else {
        return;
    };
    let Ok(mut env) = vm.attach_current_thread() else {
        return;
    };
    // SAFETY: the activity's global reference, held by the NativeActivity while it lives.
    let activity = unsafe { jni::objects::JObject::from_raw(activity as jni::sys::jobject) };
    let arg = match text.map(|t| env.new_string(t)) {
        Some(Ok(s)) => Some(s),
        Some(Err(_)) => return,
        None => None,
    };
    let args: Vec<jni::objects::JValue> = arg
        .iter()
        .map(|s| jni::objects::JValue::Object(s.as_ref()))
        .collect();
    if env.call_method(&activity, name, signature, &args).is_err() {
        let _ = env.exception_clear();
        log::warn!("Horizon: HorizonActivity.{name} failed");
    }
}

/// HorizonActivity.setKeyboard: shows or hides the soft keyboard.
#[allow(unsafe_code)]
fn set_keyboard(show: bool) {
    let Some(&(vm, activity)) = JAVA.get() else {
        return;
    };
    // SAFETY: the process's VM, which lives as long as it.
    let Ok(vm) = (unsafe { jni::JavaVM::from_raw(vm as *mut jni::sys::JavaVM) }) else {
        return;
    };
    let Ok(mut env) = vm.attach_current_thread() else {
        return;
    };
    // SAFETY: the activity's global reference, held by the NativeActivity while it lives.
    let activity = unsafe { jni::objects::JObject::from_raw(activity as jni::sys::jobject) };
    let shown = env.call_method(
        &activity,
        "setKeyboard",
        "(Z)V",
        &[jni::objects::JValue::Bool(u8::from(show))],
    );
    if let Err(e) = shown {
        let thrown = env.exception_occurred().ok();
        let _ = env.exception_clear();
        if let Some(thrown) = thrown {
            let text = env
                .call_method(&thrown, "toString", "()Ljava/lang/String;", &[])
                .and_then(|v| v.l())
                .map(jni::objects::JString::from)
                .ok()
                .and_then(|s| env.get_string(&s).ok().map(String::from));
            let _ = env.exception_clear();
            log::warn!("Horizon: setKeyboard threw {}", text.unwrap_or_default());
        }
        let what = if show { "shown" } else { "hidden" };
        log::warn!("Horizon: the soft keyboard could not be {what}: {e}");
    }
}

/// Once per install: a phone's settings for steadier frames in a settings file saved before
/// they were the defaults (entity culling, and section uploads spread over frames).
fn tune_graphics_once() {
    const MARK: &str = ".tuned-graphics-1";
    if std::path::Path::new(MARK).exists() {
        return;
    }
    if let Ok(text) = std::fs::read_to_string("horizon-graphics.txt") {
        let tuned = text
            .replace("entityCulling:false", "entityCulling:true")
            .replace("chunkUpdates:0\n", "chunkUpdates:8\n")
            .replace("uploadBudgetKiB:0\n", "uploadBudgetKiB:1024\n");
        let _ = std::fs::write("horizon-graphics.txt", tuned);
    }
    let _ = std::fs::write(MARK, "");
}

/// Horizon's own example shader pack (MIT), built in: written to `shaderpacks/` when missing,
/// so Options > Horizon Settings > Shader Packs lists it.
fn install_builtin_shaders() {
    macro_rules! file {
        ($path:literal) => {
            (
                $path,
                include_str!(concat!("../../horizon-shader-api/packs/golden_hour/", $path)),
            )
        };
    }
    const FILES: [(&str, &str); 6] = [
        file!("horizon-shaders.toml"),
        file!("README.md"),
        file!("common.wgsl"),
        file!("sky.wgsl"),
        file!("post/glow.wgsl"),
        file!("post/grade.wgsl"),
    ];
    let root = std::path::Path::new("shaderpacks/golden_hour");
    for (path, text) in FILES {
        let path = root.join(path);
        if std::fs::read_to_string(&path).is_ok_and(|t| t == text) {
            continue;
        }
        if let Some(dir) = path.parent() {
            let _ = std::fs::create_dir_all(dir);
        }
        if let Err(e) = std::fs::write(&path, text) {
            log::warn!("Horizon: built-in shader pack not written ({}): {e}", path.display());
        }
    }
}

#[allow(unsafe_code)]
#[unsafe(no_mangle)]
fn android_main(app: AndroidApp) {
    forward_output();
    // The game folder: the app's internal files folder. Files adb pushes to the external one
    // carry the shell's SELinux label, which the app may not read, so the resources are unpacked
    // with `run-as` (android/push-resources.sh) into .local/horizon-client/<version> here.
    let home = app
        .internal_data_path()
        .or_else(|| app.external_data_path())
        .unwrap_or_else(|| std::path::PathBuf::from("/data/local/tmp/horizon"));
    let _ = std::fs::create_dir_all(&home);
    let _ = std::env::set_current_dir(&home);
    // SAFETY: no other thread reads the environment yet.
    unsafe {
        std::env::set_var("HORIZON_HOME", &home);
        std::env::set_var("HORIZON_NO_DISCORD", "1");
        // Occlusion culling tests in the shader, as on Apple's tiled GPUs: with the early depth
        // test sections flickered out of sight on Adreno 740.
        std::env::set_var("HORIZON_GPU_CULL", "shader");
        // `KEY=VALUE` lines of env.txt in the game folder: the environment a terminal would give.
        for line in std::fs::read_to_string("env.txt").unwrap_or_default().lines() {
            if let Some((key, value)) = line.trim().split_once('=') {
                std::env::set_var(key.trim(), value.trim());
            }
        }
    }
    let _ = JAVA.set((app.vm_as_ptr() as usize, app.activity_as_ptr() as usize));
    let _ = horizon_client::event_loop::ANDROID_APP.set(app);
    let _ = horizon_client::event_loop::KEYBOARD.set(set_keyboard);
    let _ = horizon_client::event_loop::PICK_SKIN.set(pick_skin);
    let _ = horizon_client::event_loop::ASK_NAME.set(ask_name);
    let _ = horizon_client::event_loop::OPEN_URL.set(open_url);
    let _ = horizon_client::event_loop::COPY_TEXT.set(copy_text);
    horizon_client::telemetry::mark_start();
    logging::init(&home, "Render thread");
    set_keyboard(false);
    install_builtin_shaders();
    tune_graphics_once();
    log::info!("Horizon {} (Android, {})", crash::version(), home.display());
    crash::install(home.clone(), "client");
    // The first start: the resources prepared on the phone, then the app again.
    if !android_setup::prepared(&home)
        && let Some(app) = horizon_client::event_loop::ANDROID_APP.get()
    {
        android_setup::run(app, &home, show_status, restart);
        logging::flush();
        std::process::exit(0);
    }
    let code = match game::run() {
        Ok(()) => 0,
        Err(error) => {
            log::error!("Horizon: {error}");
            crash::report_error(&home, "client", &*error);
            1
        }
    };
    logging::flush();
    // The activity may start again in this process, and winit builds one event loop per process.
    std::process::exit(code);
}
