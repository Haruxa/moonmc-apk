//! The game's event loop. On Android it runs on the activity `android_main` was given
//! (`horizon-android`), which has to be handed to winit before the loop is built.

use winit::event_loop::EventLoop;

/// The activity `android_main` was started with.
#[cfg(target_os = "android")]
pub static ANDROID_APP: std::sync::OnceLock<winit::platform::android::activity::AndroidApp> =
    std::sync::OnceLock::new();

pub fn new() -> Result<EventLoop<()>, winit::error::EventLoopError> {
    #[allow(unused_mut)]
    let mut builder = EventLoop::builder();
    #[cfg(target_os = "android")]
    if let Some(app) = ANDROID_APP.get() {
        use winit::platform::android::EventLoopBuilderExtAndroid;
        builder.with_android_app(app.clone());
    }
    builder.build()
}

/// The game's command line: the process's, or on Android, which starts the game with none,
/// the words of `args.txt` in the game folder.
pub fn args() -> Vec<String> {
    #[cfg(target_os = "android")]
    return std::fs::read_to_string("args.txt")
        .map(|text| text.split_whitespace().map(str::to_owned).collect())
        .unwrap_or_default();
    #[cfg(not(target_os = "android"))]
    std::env::args().skip(1).collect()
}

/// What Android's soft keyboard typed, in order (`crates/horizon-android`'s JNI takes it from
/// Java, where a NativeActivity's input queue would lose text with no key code).
#[derive(Debug)]
pub enum Typed {
    Text(String),
    Backspace,
    Enter,
}

static TYPED: std::sync::Mutex<Vec<Typed>> = std::sync::Mutex::new(Vec::new());
/// Shows or hides the soft keyboard; set on Android.
pub static KEYBOARD: std::sync::OnceLock<fn(bool)> = std::sync::OnceLock::new();

pub fn push_typed(typed: Typed) {
    TYPED
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner)
        .push(typed);
}

pub fn take_typed() -> Vec<Typed> {
    std::mem::take(&mut *TYPED.lock().unwrap_or_else(std::sync::PoisonError::into_inner))
}

/// Opens the device's picker for a skin image; set on Android.
pub static PICK_SKIN: std::sync::OnceLock<fn()> = std::sync::OnceLock::new();
static PICKED: std::sync::Mutex<Vec<Vec<u8>>> = std::sync::Mutex::new(Vec::new());

/// Opens a web page / puts text on the clipboard; set on Android.
pub static OPEN_URL: std::sync::OnceLock<fn(&str)> = std::sync::OnceLock::new();
pub static COPY_TEXT: std::sync::OnceLock<fn(&str)> = std::sync::OnceLock::new();

pub fn open_url(url: &str) {
    if let Some(open) = OPEN_URL.get() {
        open(url);
    }
}

pub fn copy_text(text: &str) {
    if let Some(copy) = COPY_TEXT.get() {
        copy(text);
    }
}

/// Asks for a player name in Android's own dialog (the current one filled in); set on Android.
pub static ASK_NAME: std::sync::OnceLock<fn(&str)> = std::sync::OnceLock::new();
static NAMES: std::sync::Mutex<Vec<String>> = std::sync::Mutex::new(Vec::new());

pub fn ask_name(current: &str) {
    if let Some(ask) = ASK_NAME.get() {
        ask(current);
    }
}

/// A name the dialog gave back.
pub fn push_name(name: String) {
    NAMES
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner)
        .push(name);
}

pub fn take_names() -> Vec<String> {
    std::mem::take(&mut *NAMES.lock().unwrap_or_else(std::sync::PoisonError::into_inner))
}

pub fn pick_skin() {
    if let Some(pick) = PICK_SKIN.get() {
        pick();
    }
}

/// A skin image the picker returned (its file's bytes).
pub fn push_picked(bytes: Vec<u8>) {
    PICKED
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner)
        .push(bytes);
}

pub fn take_picked() -> Vec<Vec<u8>> {
    std::mem::take(&mut *PICKED.lock().unwrap_or_else(std::sync::PoisonError::into_inner))
}

pub fn set_keyboard(show: bool) {
    if let Some(keyboard) = KEYBOARD.get() {
        keyboard(show);
    }
}
