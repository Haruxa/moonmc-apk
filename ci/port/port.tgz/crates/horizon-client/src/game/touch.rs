//! Touch controls (Android). In menus a finger is the mouse: a tap clicks, a vertical drag
//! scrolls, a held or sideways drag presses and drags; in inventories a hold is the right
//! button (one item at a time, half a stack). In the world the left part of the screen is a
//! movement stick and a drag on the rest turns the view, in one of two modes:
//! - Aim: the crosshair. A tap uses, a hold attacks, and a big attack button sits right of
//!   the centre.
//! - Tap (old Bedrock's): no crosshair. Where the finger is, a tap uses and a hold breaks,
//!   which a ring around it fills to show; on a mob (or a player) a tap attacks and a hold
//!   interacts, as on Bedrock.
//!
//! Round buttons jump, sneak, sprint, open the inventory, pause, change the view and switch
//! the mode (kept in touch.txt in the game folder). The world's buttons go through the
//! virtual pad (`horizon-ctl pad`'s), so they act as a controller's do.
use super::{Game, Screen};
use horizon_client::{
    gamepad::{Button, PadState},
    hud::{HudAtlas, HudBatch},
};
use std::time::{Duration, Instant};
use winit::{
    application::ApplicationHandler,
    dpi::PhysicalPosition,
    event::{
        DeviceId, ElementState, MouseButton, MouseScrollDelta, Touch as Contact, TouchPhase,
        WindowEvent,
    },
    event_loop::ActiveEventLoop,
    keyboard::KeyCode,
    window::WindowId,
};

/// A tap is shorter than this, a hold longer.
const TAP: Duration = Duration::from_millis(250);
/// Movement (GUI units) a tap or a hold may have.
const STILL: f32 = 6.0;
/// The stick's reach (GUI units).
const STICK: f32 = 30.0;
/// View turn per GUI unit dragged, in mouse counts.
const LOOK: f64 = 2.4;
/// How long a tap's aim outlives the finger: its use click acts at the next tick.
const AIM_AFTER: Duration = Duration::from_millis(200);
/// The mode's file in the game folder.
const MODE_FILE: &str = "touch.txt";

#[derive(Clone, Copy, PartialEq, Default)]
pub(super) enum Mode {
    /// The crosshair and an attack button.
    #[default]
    Aim,
    /// Old Bedrock's: act where the finger is.
    Tap,
}

#[derive(Clone, Copy, PartialEq)]
enum Role {
    /// The menu pointer: the button it holds down, or scrolling, or neither yet.
    Pointer {
        pressed: Option<MouseButton>,
        scrolling: bool,
    },
    Stick,
    /// Turning the view, and what a hold did once held still past a tap.
    Look {
        hold: Hold,
    },
    Key(Key),
    Hotbar,
}

#[derive(Clone, Copy, PartialEq)]
enum Hold {
    None,
    Attack,
    /// Food, a bow, a shield in hand: held in use while the finger stays.
    Use,
    /// Tap mode's hold on a mob: one use.
    Used,
}

#[derive(Clone, Copy, PartialEq)]
enum Key {
    Jump,
    Sneak,
    Sprint,
    Inventory,
    Pause,
    View,
    Mode,
    /// F3: the debug screen (frame rate and the rest).
    Debug,
    Chat,
    /// Shift lock (touch_camera.rs).
    Lock,
    /// Aim mode's attack button (a drag on it turns the view too).
    Attack,
}

impl Key {
    const ALL: [Key; 11] = [
        Key::Jump,
        Key::Sneak,
        Key::Sprint,
        Key::Inventory,
        Key::Pause,
        Key::View,
        Key::Mode,
        Key::Debug,
        Key::Chat,
        Key::Lock,
        Key::Attack,
    ];
    /// Centre and radius in GUI units.
    fn place(self, w: f32, h: f32) -> (f32, f32, f32) {
        match self {
            Key::Jump => (w - 34.0, h - 38.0, 22.0),
            Key::Sneak => (w - 80.0, h - 22.0, 15.0),
            Key::Sprint => (w - 80.0, h - 62.0, 15.0),
            Key::Inventory => (w / 2.0 + 91.0 + 14.0, h - 11.0, 10.0),
            Key::Pause => (w - 14.0, 14.0, 11.0),
            Key::View => (w - 40.0, 14.0, 11.0),
            Key::Mode => (w - 66.0, 14.0, 11.0),
            Key::Debug => (w - 92.0, 14.0, 11.0),
            Key::Chat => (w / 2.0, 14.0, 12.0),
            Key::Lock => (54.0 + STICK + 26.0, h - 16.0, 11.0),
            Key::Attack => (w / 2.0 + w * 0.17, h / 2.0, 24.0),
        }
    }
    fn label(self, mode: Mode) -> &'static str {
        match self {
            Key::Jump => "Jump",
            Key::Sneak => "Sneak",
            Key::Sprint => "Run",
            Key::Inventory => "...",
            Key::Pause => "II",
            Key::View => "F5",
            Key::Mode if mode == Mode::Aim => "Aim",
            Key::Mode => "Tap",
            Key::Debug => "F3",
            Key::Chat => "Chat",
            Key::Lock => "Lock",
            Key::Attack => "Hit",
        }
    }
    fn shown(self, mode: Mode) -> bool {
        self != Key::Attack || mode == Mode::Aim
    }
}

#[derive(Clone, Copy)]
struct Finger {
    id: u64,
    device: DeviceId,
    role: Role,
    /// Where it went down and where it is, in GUI units.
    start: (f32, f32),
    at: (f32, f32),
    down: Instant,
    /// The farthest it got from `start`.
    moved: f32,
}

#[derive(Default)]
pub(super) struct Touch {
    /// The screen was touched: the overlay shows and drives the virtual pad.
    active: bool,
    mode: Mode,
    mode_loaded: bool,
    fingers: Vec<Finger>,
    /// Buttons pressed for one poll (a tap, the back key).
    pulses: Vec<Button>,
    /// The use and attack triggers, pulled for one poll by a tap.
    use_pulse: bool,
    attack_pulse: bool,
    /// Tap mode's last aim (GUI units) and until when a lifted finger's still counts.
    aim: Option<((f32, f32), Instant)>,
    /// The last frame's field of view (degrees, vertical) and GUI size, for aiming.
    pub(super) fov: f32,
    gui: (f32, f32),
    /// The soft keyboard is shown (`soft_keyboard.rs`, Android only).
    #[cfg_attr(not(target_os = "android"), allow(dead_code))]
    pub(super) keyboard: bool,
    /// The touchscreen, for the key events the soft keyboard's text becomes.
    #[cfg_attr(not(target_os = "android"), allow(dead_code))]
    pub(super) device: Option<DeviceId>,
    /// The span between two pinching fingers at the last move (GUI units).
    pinch: Option<f32>,
    /// A tap in a menu ended: the soft keyboard opens if it left a text field focused.
    #[cfg_attr(not(target_os = "android"), allow(dead_code))]
    pub(super) tapped: bool,
}

impl Game<'_> {
    /// The pad's menu checks, plus the prompts over the world.
    fn touch_in_menu(&self) -> bool {
        self.pad_in_menu()
            || self.dialog_open()
            || self.server_packs.prompt.is_some()
            || self.link_prompt.is_some()
    }

    fn touch_mode(&mut self) -> Mode {
        if !self.touch.mode_loaded {
            self.touch.mode_loaded = true;
            self.touch.mode = match std::fs::read_to_string(MODE_FILE).as_deref().map(str::trim) {
                Ok("tap") => Mode::Tap,
                _ => Mode::Aim,
            };
        }
        self.touch.mode
    }

    fn switch_touch_mode(&mut self) {
        let mode = match self.touch_mode() {
            Mode::Aim => Mode::Tap,
            Mode::Tap => Mode::Aim,
        };
        self.touch.mode = mode;
        let name = if mode == Mode::Tap { "tap" } else { "aim" };
        if let Err(e) = std::fs::write(MODE_FILE, name) {
            log::warn!("Horizon: touch mode not saved: {e}");
        }
    }

    /// Tap mode hides the crosshair while the touch controls are in use.
    pub(super) fn touch_hides_crosshair(&self) -> bool {
        self.touch.active && self.touch.mode == Mode::Tap
    }

    pub(super) fn touch_event(&mut self, event_loop: &ActiveEventLoop, id: WindowId, t: Contact) {
        let Some(batch) = self.gui_scale() else {
            return;
        };
        self.touch.active = true;
        self.touch.device = Some(t.device_id);
        // A finger is a mouse in menus: no controller cursor or controller keyboard.
        self.pad.in_use = false;
        self.touch_mode();
        self.last_input = Instant::now();
        let at = (
            t.location.x as f32 / batch.scale,
            t.location.y as f32 / batch.scale,
        );
        let inventory = matches!(self.screen, Screen::Inventory | Screen::Creative);
        match t.phase {
            TouchPhase::Started => {
                let role = if self.touch_in_menu() {
                    self.pointer_move(event_loop, id, t.device_id, at, &batch);
                    Role::Pointer {
                        pressed: None,
                        scrolling: false,
                    }
                } else {
                    self.world_role(at, &batch)
                };
                match role {
                    Role::Key(Key::Sneak) => self.touch_toggle(KeyCode::ShiftLeft),
                    Role::Key(Key::Sprint) => self.touch_toggle(KeyCode::ControlLeft),
                    Role::Key(Key::Inventory) => self.touch_key(KeyCode::KeyE),
                    Role::Key(Key::Pause) => self.touch.pulses.push(Button::Start),
                    Role::Key(Key::View) => self.touch_key(KeyCode::F5),
                    Role::Key(Key::Chat) => self.touch_key(KeyCode::KeyT),
                    Role::Key(Key::Lock) => self.toggle_shift_lock(),
                    Role::Key(Key::Mode) => self.switch_touch_mode(),
                    Role::Key(Key::Debug) => {
                        use horizon_client::debug_keys::KeyAction;
                        // A tap of F3 alone, as the keyboard's.
                        self.debug_key(KeyCode::F3, KeyAction::Press);
                        self.debug_key(KeyCode::F3, KeyAction::Release);
                    }
                    Role::Hotbar => self.touch_hotbar(at.0, &batch),
                    _ => {}
                }
                if matches!(role, Role::Look { .. }) && self.touch.mode == Mode::Tap {
                    self.touch.aim = Some((at, Instant::now() + AIM_AFTER));
                }
                self.touch.fingers.retain(|f| f.id != t.id);
                self.touch.fingers.push(Finger {
                    id: t.id,
                    device: t.device_id,
                    role,
                    start: at,
                    at,
                    down: Instant::now(),
                    moved: 0.0,
                });
            }
            TouchPhase::Moved => {
                let Some(i) = self.touch.fingers.iter().position(|f| f.id == t.id) else {
                    return;
                };
                let mut f = self.touch.fingers[i];
                let (dx, dy) = (at.0 - f.at.0, at.1 - f.at.1);
                f.at = at;
                f.moved = f.moved.max(distance(f.start, at));
                match &mut f.role {
                    Role::Pointer { pressed, scrolling } => {
                        let (sx, sy) = (at.0 - f.start.0, at.1 - f.start.1);
                        // The creative grid scrolls under the finger, as a list does.
                        let grid = self.screen == Screen::Creative && in_creative_grid(f.start, &batch);
                        if pressed.is_none() && !*scrolling && f.moved > STILL {
                            if (grid || !inventory) && sy.abs() > sx.abs() * 1.5 {
                                *scrolling = true;
                            } else {
                                *pressed = Some(MouseButton::Left);
                                self.pointer_button(
                                    event_loop,
                                    id,
                                    f.device,
                                    MouseButton::Left,
                                    true,
                                );
                            }
                        }
                        // MoonMC: в пинах 10-30 у игры нет ни drag-а игрока на титуле,
                        // ни сетки гардероба, ни drag_rows у творческого экрана —
                        // остаётся обычная прокрутка колесом.
                        if *scrolling {
                            let delta = MouseScrollDelta::PixelDelta(PhysicalPosition::new(
                                0.0,
                                f64::from(dy * batch.scale) * 0.5,
                            ));
                            self.window_event(
                                event_loop,
                                id,
                                WindowEvent::MouseWheel {
                                    device_id: f.device,
                                    delta,
                                    phase: TouchPhase::Moved,
                                },
                            );
                        } else {
                            self.pointer_move(event_loop, id, f.device, at, &batch);
                        }
                    }
                    Role::Look { .. } | Role::Key(Key::Attack)
                        if self.screen == Screen::Playing && self.title.is_none() =>
                    {
                        // Two fingers on the view pinch (touch_camera.rs); one turns it.
                        let other = self
                            .touch
                            .fingers
                            .iter()
                            .find(|o| o.id != f.id && matches!(o.role, Role::Look { .. }))
                            .map(|o| o.at);
                        if let (Some(other), Role::Look { .. }) = (other, f.role) {
                            f.moved = f.moved.max(STILL * 4.0);
                            let span = distance(at, other).max(1.0);
                            if let Some(before) = self.touch.pinch {
                                self.touch_pinch(before / span);
                            }
                            self.touch.pinch = Some(span);
                        } else {
                            self.touch_turn(dx, dy, LOOK);
                        }
                        if matches!(f.role, Role::Look { .. }) && self.touch.mode == Mode::Tap {
                            self.touch.aim = Some((at, Instant::now() + AIM_AFTER));
                        }
                    }
                    _ => {}
                }
                self.touch.fingers[i] = f;
            }
            TouchPhase::Ended | TouchPhase::Cancelled => {
                let Some(i) = self.touch.fingers.iter().position(|f| f.id == t.id) else {
                    return;
                };
                let f = self.touch.fingers.remove(i);
                self.touch.pinch = None;
                let cancelled = t.phase == TouchPhase::Cancelled;
                match f.role {
                    Role::Pointer { pressed, scrolling } => {
                        if scrolling && self.screen == Screen::Creative {
                            self.creative_screen.snap(&self.pack.names);
                        }
                        let page = self.touch_page();
                        self.pointer_move(event_loop, id, f.device, at, &batch);
                        if let Some(button) = pressed {
                            self.pointer_button(event_loop, id, f.device, button, false);
                        } else if !scrolling && !cancelled {
                            let left = MouseButton::Left;
                            self.pointer_button(event_loop, id, f.device, left, true);
                            self.pointer_button(event_loop, id, f.device, left, false);
                        }
                        // A tap that opened another screen (Singleplayer, whose world list
                        // focuses its search) is not a tap on a field.
                        self.touch.tapped = !scrolling && !cancelled && self.touch_page() == page;
                    }
                    Role::Look { hold } => {
                        if self.touch.mode == Mode::Tap {
                            self.touch.aim = Some((f.at, Instant::now() + AIM_AFTER));
                        }
                        if hold == Hold::None
                            && !cancelled
                            && f.down.elapsed() < TAP
                            && f.moved < STILL
                        {
                            if self.touch.mode == Mode::Tap && self.touch_on_mob() {
                                self.touch.attack_pulse = true;
                            } else {
                                self.touch.use_pulse = true;
                            }
                        }
                    }
                    _ => {}
                }
            }
        }
    }

    /// What a finger put down in the world drives.
    fn world_role(&self, at: (f32, f32), batch: &HudBatch) -> Role {
        let (w, h) = (batch.width, batch.height);
        for key in Key::ALL {
            let (x, y, r) = key.place(w, h);
            if key.shown(self.touch.mode) && distance(at, (x, y)) <= r + 4.0 {
                return Role::Key(key);
            }
        }
        if (0.0..=182.0).contains(&(at.0 - (w / 2.0 - 91.0))) && at.1 >= h - 23.0 {
            return Role::Hotbar;
        }
        if at.0 < w * 0.4 {
            Role::Stick
        } else {
            Role::Look { hold: Hold::None }
        }
    }

    fn touch_hotbar(&mut self, x: f32, batch: &HudBatch) {
        let slot = ((x - (batch.width / 2.0 - 91.0)) / 20.0).floor();
        self.selected = slot.clamp(0.0, 8.0) as usize;
    }

    /// A key's default mapping pressed and released (chat, inventory, view), as the keyboard
    /// does: through the pad, the menus would take the controller's cursor and keyboard.
    fn touch_key(&mut self, key: KeyCode) {
        let pressed = self
            .mapped_key(key, true, false)
            .and_then(|()| self.mapped_key(key, false, false));
        if let Err(e) = pressed {
            log::warn!("Horizon: touch {key:?}: {e}");
        }
    }

    /// The screen a tap was on: a tap that changes it did not aim at a field.
    fn touch_page(
        &self,
    ) -> (
        Screen,
        Option<std::mem::Discriminant<horizon_client::title::Mode>>,
        bool,
        bool,
    ) {
        (
            self.screen,
            self.title.as_ref().map(|t| std::mem::discriminant(&t.mode)),
            self.sign_edit.is_some(),
            self.book.is_some(),
        )
    }

    pub(super) fn touch_active(&self) -> bool {
        self.touch.active
    }

    /// Sneak and sprint flip at each press of their button, whether the game holds or
    /// toggles their keys.
    fn touch_toggle(&mut self, key: KeyCode) {
        let toggles = match key {
            KeyCode::ShiftLeft => self.settings.toggle_crouch,
            _ => self.settings.toggle_sprint,
        };
        let result = if toggles {
            self.mapped_key(key, true, false)
                .and_then(|()| self.mapped_key(key, false, false))
        } else {
            let held = self.keys.contains(&key);
            self.mapped_key(key, !held, false)
        };
        if let Err(e) = result {
            log::warn!("Horizon: touch {key:?}: {e}");
        }
    }

    fn pointer_move(
        &mut self,
        event_loop: &ActiveEventLoop,
        id: WindowId,
        device_id: DeviceId,
        at: (f32, f32),
        batch: &HudBatch,
    ) {
        let position = PhysicalPosition::new(
            f64::from(at.0 * batch.scale),
            f64::from(at.1 * batch.scale),
        );
        self.window_event(
            event_loop,
            id,
            WindowEvent::CursorMoved {
                device_id,
                position,
            },
        );
    }

    fn pointer_button(
        &mut self,
        event_loop: &ActiveEventLoop,
        id: WindowId,
        device_id: DeviceId,
        button: MouseButton,
        pressed: bool,
    ) {
        let state = if pressed {
            ElementState::Pressed
        } else {
            ElementState::Released
        };
        self.window_event(
            event_loop,
            id,
            WindowEvent::MouseInput {
                device_id,
                state,
                button,
            },
        );
    }

    /// Android's back key: the pad's Start, which pauses in the world and goes back in menus.
    pub(super) fn touch_back(&mut self) {
        self.touch.pulses.push(Button::Start);
    }

    /// Before the pads are read: the virtual pad the fingers hold, and an inventory's
    /// right button for a finger held still.
    pub(super) fn touch_frame(&mut self, event_loop: &ActiveEventLoop) {
        if !self.touch.active {
            return;
        }
        if let Some(window) = self.window.as_ref().map(|w| w.id())
            && matches!(self.screen, Screen::Inventory | Screen::Creative)
        {
            for i in 0..self.touch.fingers.len() {
                let f = self.touch.fingers[i];
                if let Role::Pointer {
                    pressed: None,
                    scrolling: false,
                } = f.role
                    && f.down.elapsed() >= TAP
                    && f.moved < STILL
                {
                    self.touch.fingers[i].role = Role::Pointer {
                        pressed: Some(MouseButton::Right),
                        scrolling: false,
                    };
                    self.pointer_button(event_loop, window, f.device, MouseButton::Right, true);
                }
            }
        }
        let mut state = PadState::default();
        let in_menu = self.touch_in_menu();
        let tap_mode = self.touch.mode == Mode::Tap;
        for i in 0..self.touch.fingers.len() {
            let f = self.touch.fingers[i];
            match f.role {
                Role::Stick if !in_menu => {
                    let (dx, dy) = (f.at.0 - f.start.0, f.at.1 - f.start.1);
                    let length = (dx * dx + dy * dy).sqrt().max(STICK);
                    state.left = [dx / length, -dy / length];
                }
                Role::Look { mut hold } if !in_menu => {
                    if tap_mode {
                        self.touch.aim = Some((f.at, Instant::now() + AIM_AFTER));
                    }
                    if hold == Hold::None && f.down.elapsed() >= TAP && f.moved < STILL {
                        hold = if tap_mode && self.touch_on_mob() {
                            self.touch.use_pulse = true;
                            Hold::Used
                        } else if self.held_uses_over_time() {
                            Hold::Use
                        } else {
                            Hold::Attack
                        };
                        self.touch.fingers[i].role = Role::Look { hold };
                    }
                    match hold {
                        Hold::Attack => state.triggers[1] = 1.0,
                        Hold::Use => state.triggers[0] = 1.0,
                        Hold::None | Hold::Used => {}
                    }
                }
                Role::Key(Key::Attack) if !in_menu => state.triggers[1] = 1.0,
                Role::Key(Key::Jump) => state.set(Button::South, true),
                _ => {}
            }
        }
        // Free third person: the player walks where the stick points from the camera, and
        // faces the aim to hit or use.
        if !in_menu {
            state.left = self.orbit_walk(state.left);
            if state.triggers[0] > 0.0 || state.triggers[1] > 0.0 || self.touch.use_pulse || self.touch.attack_pulse {
                let aim = self.touch_aim();
                self.orbit_face(aim);
            }
        }
        for button in std::mem::take(&mut self.touch.pulses) {
            state.set(button, true);
        }
        if std::mem::take(&mut self.touch.use_pulse) {
            state.triggers[0] = 1.0;
        }
        if std::mem::take(&mut self.touch.attack_pulse) {
            state.triggers[1] = 1.0;
        }
        self.pad.injected = state;
    }

    /// Tap mode's aim: the yaw and pitch of the ray through the finger, while one is down or
    /// just lifted.
    fn touch_aim(&self) -> Option<(f32, f32)> {
        let (w, h) = self.touch.gui;
        let at = if self.touch.mode == Mode::Tap {
            let (at, until) = self.touch.aim?;
            let held = self
                .touch
                .fingers
                .iter()
                .any(|f| matches!(f.role, Role::Look { .. }));
            if !held && Instant::now() > until {
                return None;
            }
            at
        } else if self.touch.active && !self.camera_type.first_person() {
            // Third person aims through the screen's centre (the crosshair, shift lock's ring).
            (w / 2.0, h / 2.0)
        } else {
            return None;
        };
        let (w, h) = self.touch.gui;
        // The camera the frame was drawn from: the eye, or behind or before the player in
        // the third-person views.
        let (camera, view_yaw, view_pitch, fov) = self.locator_camera?;
        if w <= 0.0 || h <= 0.0 || fov <= 0.0 {
            return None;
        }
        let ndc = (
            f64::from(2.0 * at.0 / w - 1.0),
            f64::from(1.0 - 2.0 * at.1 / h),
        );
        let tan_v = (f64::from(fov) / 2.0).to_radians().tan();
        let tan_h = tan_v * f64::from(w / h);
        let f = glam::DVec3::from_array(super::view_vector(view_yaw, view_pitch));
        let up = glam::DVec3::from_array(super::view_vector(view_yaw, view_pitch - 90.0));
        let right = f.cross(up);
        let mut dir = (f + right * (ndc.0 * tan_h) + up * (ndc.1 * tan_v)).normalize();
        // Away from the eye, aim from it at what the finger is on (or at the far end of the
        // reach): picking casts from the eye.
        let eye = glam::DVec3::from_array(self.eye_position()?);
        let camera = glam::DVec3::from_array(camera);
        let away = camera.distance(eye);
        if away > 0.01 {
            let reach = self.reach() + away;
            let point = self
                .clip_ray(camera.to_array(), dir.to_array(), reach)
                .map_or(camera + dir * reach, |hit| glam::DVec3::from_array(hit.point));
            dir = (point - eye).normalize_or(dir);
        }
        let pitch = (-dir.y).asin().to_degrees();
        let yaw = (-dir.x).atan2(dir.z).to_degrees();
        Some((yaw as f32, pitch as f32))
    }

    /// Tap mode: a mob or a player is under the finger, before any block.
    fn touch_on_mob(&mut self) -> bool {
        self.with_touch_aim(|g| {
            let before = |hit: Option<f64>| hit.is_some_and(|d| g.before_block(d));
            before(g.mob_hit().map(|h| h.1)) || before(g.guest_hit().map(|h| h.1))
        })
    }

    /// Third person with the touch controls in aim mode shows the crosshair (shift lock its
    /// ring instead).
    pub(super) fn touch_third_person_crosshair(&self) -> bool {
        self.touch.active && self.touch.mode == Mode::Aim && !self.shift_locked()
    }

    /// Runs `f` with the view turned to tap mode's aim, if there is one.
    pub(super) fn with_touch_aim<R>(&mut self, f: impl FnOnce(&mut Self) -> R) -> R {
        let Some((yaw, pitch)) = self.touch_aim() else {
            return f(self);
        };
        let saved = (self.yaw, self.pitch);
        self.yaw = yaw;
        self.pitch = pitch;
        let result = f(self);
        // Turns made meanwhile still count.
        self.yaw = saved.0 + (self.yaw - yaw);
        self.pitch = saved.1 + (self.pitch - pitch);
        result
    }

    /// The block the outline goes round: tap mode's aim, none in tap mode with no finger
    /// down, else the crosshair's.
    pub(super) fn touch_pick(&mut self) -> Option<super::Hit> {
        if self.touch.active && self.touch.mode == Mode::Tap && self.touch_aim().is_none() {
            return None;
        }
        self.with_touch_aim(|g| g.pick())
    }

    pub(super) fn draw_touch(&mut self, batch: &mut HudBatch) {
        self.touch.gui = (batch.width, batch.height);
        if !self.touch.active || self.touch_in_menu() || self.player.is_none() {
            return;
        }
        let atlas = &self.gui.atlas;
        let (w, h) = (batch.width, batch.height);
        let mode = self.touch.mode;
        let stick = self.touch.fingers.iter().find(|f| f.role == Role::Stick);
        let (base, knob) = match stick {
            Some(f) => {
                let (dx, dy) = (f.at.0 - f.start.0, f.at.1 - f.start.1);
                let length = (dx * dx + dy * dy).sqrt().max(STICK);
                (
                    f.start,
                    (
                        f.start.0 + dx / length * STICK,
                        f.start.1 + dy / length * STICK,
                    ),
                )
            }
            None => ((54.0, h - 54.0), (54.0, h - 54.0)),
        };
        disc(batch, atlas, base, STICK + 6.0, 0x30FF_FFFF);
        disc(batch, atlas, knob, 14.0, 0x60FF_FFFF);
        let sneaking = self.keys.contains(&KeyCode::ShiftLeft);
        let sprinting = self.keys.contains(&KeyCode::ControlLeft);
        for key in Key::ALL {
            if !key.shown(mode) {
                continue;
            }
            let (x, y, r) = key.place(w, h);
            let held = self.touch.fingers.iter().any(|f| f.role == Role::Key(key))
                || (key == Key::Sneak && sneaking)
                || (key == Key::Sprint && sprinting)
                || (key == Key::Lock && self.shift_locked());
            disc(
                batch,
                atlas,
                (x, y),
                r,
                if held { 0x90FF_FFFF } else { 0x40FF_FFFF },
            );
            let label = key.label(mode);
            let tw = HudBatch::text_width(atlas, label);
            batch.text(atlas, label, x - tw / 2.0, y - 4.0, 0xE0FF_FFFF, true);
        }
        // Shift lock's aim: a ring at the centre.
        if self.shift_locked() {
            ring(batch, atlas, (w / 2.0, h / 2.0), 4.0, 5.5, 0xE0FF_FFFF);
        }
        // Tap mode: a ring round the finger that fills as the block under it breaks.
        if mode == Mode::Tap {
            let progress = self.mining.as_ref().map_or(0.0, |m| m.progress.clamp(0.0, 1.0));
            for f in &self.touch.fingers {
                if let Role::Look { hold } = f.role {
                    ring(batch, atlas, f.at, RING - 3.0, RING, 0xB0FF_FFFF);
                    if hold == Hold::Attack {
                        pie(batch, atlas, f.at, RING - 3.0, progress, 0x80FF_FFFF);
                    }
                }
            }
        }
    }
}

/// Inside the creative screen's 9x5 item grid (GUI units).
fn in_creative_grid((x, y): (f32, f32), batch: &HudBatch) -> bool {
    let (ox, oy) = Game::creative_origin(batch);
    (ox + 9.0..ox + 9.0 + 9.0 * 18.0).contains(&x) && (oy + 18.0..oy + 18.0 + 5.0 * 18.0).contains(&y)
}

fn distance(a: (f32, f32), b: (f32, f32)) -> f32 {
    ((a.0 - b.0).powi(2) + (a.1 - b.1).powi(2)).sqrt()
}

const SIDES: usize = 48;
/// Tap mode's ring round the finger (GUI units).
const RING: f32 = 22.0;

fn corner(x: f32, y: f32, r: f32, i: usize) -> [f32; 2] {
    let a = i as f32 / SIDES as f32 * std::f32::consts::TAU;
    [x + r * a.cos(), y + r * a.sin()]
}

/// A filled circle as a fan of thin quads.
fn disc(batch: &mut HudBatch, atlas: &HudAtlas, (x, y): (f32, f32), r: f32, color: u32) {
    for i in 0..SIDES {
        let (p, q) = (corner(x, y, r, i), corner(x, y, r, i + 1));
        batch.fill_quad(atlas, [[x, y], p, q, q], color);
    }
}

/// A circle's outline between radii `inner` and `outer`.
fn ring(
    batch: &mut HudBatch,
    atlas: &HudAtlas,
    (x, y): (f32, f32),
    inner: f32,
    outer: f32,
    color: u32,
) {
    for i in 0..SIDES {
        batch.fill_quad(
            atlas,
            [
                corner(x, y, inner, i),
                corner(x, y, outer, i),
                corner(x, y, outer, i + 1),
                corner(x, y, inner, i + 1),
            ],
            color,
        );
    }
}

/// A disc's share `fraction`, clockwise from the top.
fn pie(
    batch: &mut HudBatch,
    atlas: &HudAtlas,
    (x, y): (f32, f32),
    r: f32,
    fraction: f32,
    color: u32,
) {
    let end = fraction * std::f32::consts::TAU;
    let point = |a: f32| {
        let a = a - std::f32::consts::FRAC_PI_2;
        [x + r * a.cos(), y + r * a.sin()]
    };
    let step = std::f32::consts::TAU / SIDES as f32;
    let mut a = 0.0;
    while a < end {
        let b = (a + step).min(end);
        let (p, q) = (point(a), point(b));
        batch.fill_quad(atlas, [[x, y], p, q, q], color);
        a = b;
    }
}
