//! The touch controls' camera (Horizon's own, Roblox-like):
//! - Third person orbits the player: a drag turns the camera, not the player, who turns to
//!   where they walk, hit or use. There is no front view: the orbit shows the front.
//! - A pinch moves the camera nearer or farther; all the way in it is first person, where a
//!   pinch zooms the view (as OK Zoomer's key), and pinching out from there goes back out.
//! - Shift lock: the camera behind and right of the player, turning them with it, the view
//!   fixed until the lock is let go, a ring at the centre to aim with.
use super::{Game, perspective::CameraType};

/// The default third-person distance (`camera_distance`), and the pinch's range.
pub(super) const DISTANCE: f32 = 4.0;
const NEAREST: f32 = 1.0;
const FARTHEST: f32 = 10.0;
/// Shift lock's distance and how far right of the player it looks from.
const LOCK_DISTANCE: f32 = 3.0;
const SHOULDER: f32 = 0.9;
/// First person's pinch zoom, at most.
const MAX_ZOOM: f32 = 10.0;
/// Degrees an orbit turns per GUI unit dragged.
pub(super) const ORBIT_TURN: f32 = 0.36;

/// What shift lock changed, to put back when it is let go.
#[derive(Clone, Copy)]
struct Saved {
    camera: CameraType,
    distance: f32,
    zoom: f32,
}

pub(super) struct Camera {
    /// The orbit's yaw and pitch while third person orbits.
    orbit: Option<(f32, f32)>,
    pub(super) distance: f32,
    /// First person's pinch zoom (1: none).
    pub(super) zoom: f32,
    lock: Option<Saved>,
}

impl Default for Camera {
    fn default() -> Self {
        Self {
            orbit: None,
            distance: DISTANCE,
            zoom: 1.0,
            lock: None,
        }
    }
}

impl Game<'_> {
    /// The touch camera is in use: the touch controls, in a world.
    fn touch_camera_on(&self) -> bool {
        self.touch_active() && self.player.is_some()
    }

    pub(super) fn shift_locked(&self) -> bool {
        self.touch_camera.lock.is_some()
    }

    /// Third person orbits freely (not shift-locked): the orbit, started from the view.
    pub(super) fn free_orbit(&mut self) -> Option<&mut (f32, f32)> {
        if !self.touch_camera_on()
            || self.camera_type.first_person()
            || self.touch_camera.lock.is_some()
        {
            self.touch_camera.orbit = None;
            return None;
        }
        let (yaw, pitch) = (self.yaw, self.pitch);
        Some(self.touch_camera.orbit.get_or_insert((yaw, pitch)))
    }

    /// The rotation the camera renders from, when the touch camera sets it.
    pub(super) fn touch_view_rotation(&self) -> Option<(f32, f32)> {
        self.touch_camera.orbit.filter(|_| !self.camera_type.first_person())
    }

    /// The third-person distance, when the touch camera sets it.
    pub(super) fn touch_view_distance(&self) -> Option<f64> {
        if !self.touch_camera_on() || self.camera_type.first_person() {
            return None;
        }
        Some(f64::from(if self.touch_camera.lock.is_some() {
            LOCK_DISTANCE
        } else {
            self.touch_camera.distance
        }))
    }

    /// How far right of the player shift lock looks from.
    pub(super) fn touch_shoulder(&self) -> Option<f32> {
        self.touch_camera.lock.is_some().then_some(SHOULDER)
    }

    /// A drag that turns the view: the orbit in free third person, else the player.
    pub(super) fn touch_turn(&mut self, dx: f32, dy: f32, look: f64) {
        if let Some((yaw, pitch)) = self.free_orbit() {
            *yaw += dx * ORBIT_TURN;
            *pitch = (*pitch + dy * ORBIT_TURN).clamp(-90.0, 90.0);
            return;
        }
        let zoom = f64::from(self.touch_camera.zoom);
        self.mouse.on_move(
            0.0,
            0.0,
            f64::from(dx) * look / zoom,
            f64::from(dy) * look / zoom,
            true,
            true,
        );
    }

    /// Two fingers moved apart (`ratio` < 1) or together (> 1).
    pub(super) fn touch_pinch(&mut self, ratio: f32) {
        if self.touch_camera.lock.is_some() || !self.touch_camera_on() {
            return;
        }
        if self.camera_type.first_person() {
            let zoom = self.touch_camera.zoom;
            if ratio > 1.0 && zoom <= 1.0 {
                // Out of first person: the orbit starts right behind the head.
                self.camera_type = CameraType::ThirdPersonBack;
                self.touch_camera.distance = NEAREST + 0.2;
                self.touch_camera.orbit = Some((self.yaw, self.pitch));
            } else {
                self.touch_camera.zoom = (zoom / ratio).clamp(1.0, MAX_ZOOM);
            }
            return;
        }
        let distance = self.touch_camera.distance * ratio;
        if distance < NEAREST && ratio < 1.0 {
            self.enter_first_person();
        } else {
            self.touch_camera.distance = distance.clamp(NEAREST, FARTHEST);
        }
    }

    /// First person, looking where the orbit looked.
    fn enter_first_person(&mut self) {
        if let Some((yaw, pitch)) = self.touch_camera.orbit.take() {
            self.yaw = yaw;
            self.pitch = pitch;
        }
        self.camera_type = CameraType::FirstPerson;
        self.touch_camera.distance = DISTANCE;
        self.touch_camera.zoom = 1.0;
    }

    /// F5 with the touch camera: first person and third person (the orbit shows the front),
    /// none while shift-locked.
    pub(super) fn touch_cycle_camera(&mut self) -> bool {
        if !self.touch_camera_on() {
            return false;
        }
        if self.touch_camera.lock.is_none() {
            if self.camera_type.first_person() {
                self.camera_type = CameraType::ThirdPersonBack;
                self.touch_camera.distance = DISTANCE;
                self.touch_camera.zoom = 1.0;
                self.touch_camera.orbit = Some((self.yaw, self.pitch));
            } else {
                self.enter_first_person();
            }
        }
        true
    }

    /// The lock button: shift lock on, or back to the camera before it.
    pub(super) fn toggle_shift_lock(&mut self) {
        if let Some(saved) = self.touch_camera.lock.take() {
            self.camera_type = saved.camera;
            self.touch_camera.distance = saved.distance;
            self.touch_camera.zoom = saved.zoom;
            if !self.camera_type.first_person() {
                self.touch_camera.orbit = Some((self.yaw, self.pitch));
            }
            return;
        }
        // The player faces where the camera looked.
        if let Some((yaw, pitch)) = self.touch_camera.orbit.take() {
            self.yaw = yaw;
            self.pitch = pitch;
        }
        self.touch_camera.lock = Some(Saved {
            camera: self.camera_type,
            distance: self.touch_camera.distance,
            zoom: self.touch_camera.zoom,
        });
        self.camera_type = CameraType::ThirdPersonBack;
        self.touch_camera.zoom = 1.0;
    }

    /// First person's pinch zoom of the field of view.
    pub(super) fn touch_fov_zoom(&self) -> f32 {
        if self.camera_type.first_person() {
            self.touch_camera.zoom
        } else {
            1.0
        }
    }

    /// The stick in free third person: the player turns to where it points, seen from the
    /// camera, and walks that way (its tilt becomes forward). Returns the stick to use.
    pub(super) fn orbit_walk(&mut self, stick: [f32; 2]) -> [f32; 2] {
        let Some(&mut (orbit_yaw, orbit_pitch)) = self.free_orbit() else {
            return stick;
        };
        let tilt = (stick[0] * stick[0] + stick[1] * stick[1]).sqrt();
        if tilt < 0.05 {
            return stick;
        }
        let want = orbit_yaw + stick[0].atan2(stick[1]).to_degrees();
        let turn = (want - self.yaw + 540.0).rem_euclid(360.0) - 180.0;
        self.yaw += turn * 0.35;
        // Swimming and flying go where the camera looks up or down.
        self.pitch = orbit_pitch;
        [0.0, tilt.min(1.0)]
    }

    /// Hitting or using in free third person: the player turns to the aim and stays so.
    pub(super) fn orbit_face(&mut self, aim: Option<(f32, f32)>) {
        if self.free_orbit().is_some()
            && let Some((yaw, pitch)) = aim
        {
            self.yaw = yaw;
            self.pitch = pitch;
        }
    }
}
