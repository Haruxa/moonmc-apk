//! Horizon on Android: the player's own download of Minecraft 26.3 from Mojang, for a signed-in
//! account that owns Minecraft: Java Edition, as the desktop launcher's (`launcher/src/mojang.rs`)
//! and other launchers do: the version JSON research-lock.json pins, the client and server jars,
//! the libraries and the assets, each checked against its sha1, in the official launcher's
//! layout. A download stopped half way keeps the files it finished.
use serde_json::Value;
use sha1::Digest;
use std::path::{Component, Path, PathBuf};
use std::sync::Mutex;
use std::sync::atomic::{AtomicUsize, Ordering::Relaxed};
use std::time::Duration;

const OBJECTS: &str = "https://resources.download.minecraft.net";

struct File {
    url: String,
    sha1: String,
    size: Option<u64>,
    path: PathBuf,
}

fn get(url: &str) -> Result<Vec<u8>, String> {
    let response = ureq::AgentBuilder::new()
        .timeout(Duration::from_secs(60))
        .build()
        .get(url)
        .call()
        .map_err(|e| format!("{url}: {e}"))?;
    let mut body = Vec::new();
    std::io::Read::read_to_end(&mut response.into_reader(), &mut body)
        .map_err(|e| format!("{url}: {e}"))?;
    Ok(body)
}

fn sha1_hex(data: &[u8]) -> String {
    sha1::Sha1::digest(data)
        .iter()
        .map(|b| format!("{b:02x}"))
        .collect()
}

fn sha1_file(path: &Path) -> Option<String> {
    std::fs::read(path).ok().map(|d| sha1_hex(&d))
}

fn write(path: &Path, body: &[u8]) -> Result<(), String> {
    if let Some(dir) = path.parent() {
        std::fs::create_dir_all(dir).map_err(|e| e.to_string())?;
    }
    let partial = path.with_extension("partial");
    std::fs::write(&partial, body).map_err(|e| e.to_string())?;
    std::fs::rename(&partial, path).map_err(|e| e.to_string())
}

fn text(v: &Value, key: &str) -> Result<String, String> {
    v[key]
        .as_str()
        .map(String::from)
        .ok_or_else(|| format!("The version file has no {key}"))
}

/// A path from the version file, refused if it could leave the folder.
fn relative(path: &str) -> Result<PathBuf, String> {
    let safe = !path.contains('\\')
        && Path::new(path)
            .components()
            .all(|c| matches!(c, Component::Normal(_)));
    safe.then(|| PathBuf::from(path))
        .ok_or_else(|| format!("Unsafe path {path:?} in the version file"))
}

/// Whether a library's rules let Linux use it (Android runs the Linux libraries' Java): the
/// last rule that matches decides.
fn allowed(library: &Value) -> bool {
    let Some(rules) = library["rules"].as_array() else {
        return true;
    };
    rules
        .iter()
        .rfind(|rule| rule["os"]["name"].as_str().is_none_or(|name| name == "linux"))
        .is_some_and(|rule| rule["action"] == "allow")
}

fn fetch_all(files: &[File], jobs: usize, what: &str, log: &dyn Fn(&str)) -> Result<(), String> {
    let next = AtomicUsize::new(0);
    let done = AtomicUsize::new(0);
    let failed = Mutex::new(None::<String>);
    std::thread::scope(|scope| {
        let workers: Vec<_> = (0..jobs.clamp(1, files.len().max(1)))
            .map(|_| {
                scope.spawn(|| {
                    while let Some(file) = files.get(next.fetch_add(1, Relaxed)) {
                        if failed.lock().map_or(true, |f| f.is_some()) {
                            break;
                        }
                        if sha1_file(&file.path).as_deref() != Some(file.sha1.as_str()) {
                            let got = get(&file.url).and_then(|body| {
                                if file.size.is_some_and(|s| s != body.len() as u64)
                                    || sha1_hex(&body) != file.sha1
                                {
                                    return Err(format!("{} is not the file Mojang lists", file.url));
                                }
                                write(&file.path, &body)
                            });
                            if let Err(e) = got
                                && let Ok(mut f) = failed.lock()
                            {
                                f.get_or_insert(e);
                            }
                        }
                        done.fetch_add(1, Relaxed);
                    }
                })
            })
            .collect();
        while !workers.iter().all(|w| w.is_finished()) {
            std::thread::sleep(Duration::from_millis(500));
            log(&format!(
                "Downloading {what} from Mojang: {} of {} files",
                done.load(Relaxed),
                files.len()
            ));
        }
    });
    failed
        .into_inner()
        .unwrap_or_else(|e| e.into_inner())
        .map_or(Ok(()), Err)
}

/// Downloads Minecraft `version` (its version JSON pinned by `manifest_sha1`) into `dir`, and
/// its server jar as `dir/server.jar`.
pub fn download(
    dir: &Path,
    version: &str,
    manifest_sha1: &str,
    log: &dyn Fn(&str),
) -> Result<(), String> {
    let versions = dir.join("versions").join(version);
    let manifest_path = versions.join(format!("{version}.json"));
    if sha1_file(&manifest_path).as_deref() != Some(manifest_sha1) {
        log("Downloading the version file from Mojang...");
        let url = format!("https://piston-meta.mojang.com/v1/packages/{manifest_sha1}/{version}.json");
        let body = get(&url)?;
        if sha1_hex(&body) != manifest_sha1 {
            return Err("Mojang's version file is not the one Horizon pins".into());
        }
        write(&manifest_path, &body)?;
    }
    let manifest: Value = serde_json::from_slice(
        &std::fs::read(&manifest_path).map_err(|e| e.to_string())?,
    )
    .map_err(|e| e.to_string())?;
    let jar = |side: &str, path: PathBuf| -> Result<File, String> {
        let d = &manifest["downloads"][side];
        Ok(File {
            url: text(d, "url")?,
            sha1: text(d, "sha1")?,
            size: d["size"].as_u64(),
            path,
        })
    };
    let mut game = vec![
        jar("client", versions.join(format!("{version}.jar")))?,
        jar("server", dir.join("server.jar"))?,
    ];
    for library in manifest["libraries"]
        .as_array()
        .ok_or("The version file has no libraries")?
        .iter()
        .filter(|l| allowed(l))
    {
        let artifact = &library["downloads"]["artifact"];
        if artifact.is_null() {
            continue;
        }
        game.push(File {
            url: text(artifact, "url")?,
            sha1: text(artifact, "sha1")?,
            size: artifact["size"].as_u64(),
            path: dir
                .join("libraries")
                .join(relative(&text(artifact, "path")?)?),
        });
    }
    fetch_all(&game, 8, "the game and its libraries", log)?;
    let index = &manifest["assetIndex"];
    let index = File {
        url: text(index, "url")?,
        sha1: text(index, "sha1")?,
        size: index["size"].as_u64(),
        path: dir
            .join("assets/indexes")
            .join(relative(&format!("{}.json", text(index, "id")?))?),
    };
    fetch_all(std::slice::from_ref(&index), 1, "the asset index", log)?;
    let index: Value = serde_json::from_slice(
        &std::fs::read(&index.path).map_err(|e| e.to_string())?,
    )
    .map_err(|e| e.to_string())?;
    let mut hashes: Vec<(String, Option<u64>)> = index["objects"]
        .as_object()
        .ok_or("The asset index has no objects")?
        .values()
        .filter_map(|o| Some((o["hash"].as_str()?.to_owned(), o["size"].as_u64())))
        .collect();
    hashes.sort();
    hashes.dedup_by(|a, b| a.0 == b.0);
    let objects: Vec<File> = hashes
        .into_iter()
        .filter(|(h, _)| h.len() == 40 && h.bytes().all(|b| b.is_ascii_hexdigit()))
        .map(|(hash, size)| {
            let path = format!("{}/{hash}", &hash[..2]);
            File {
                url: format!("{OBJECTS}/{path}"),
                sha1: hash,
                size,
                path: dir.join("assets/objects").join(path),
            }
        })
        .collect();
    fetch_all(&objects, 16, "the assets and sounds", log)
}
